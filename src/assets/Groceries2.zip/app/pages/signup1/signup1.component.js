"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var Signup1Component = (function () {
    function Signup1Component(router, userService, page) {
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        //this.user.email = "test@mastercard.com";
        //this.user.password = "password";
    }
    Signup1Component.prototype.ngOnInit = function () {
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
    };
    Signup1Component.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    Signup1Component.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    Signup1Component.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplayCust();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    Signup1Component.prototype.toggleDisplayCust11 = function () {
        this.router.navigate(["/signupc"]);
    };
    Signup1Component.prototype.toggleDisplayMer1 = function () {
        this.router.navigate(["/signupm"]);
    };
    Signup1Component.prototype.toggleDisplay = function () {
        this.router.navigate(["/"]);
    };
    Signup1Component.prototype.toggleDisplayMer = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to validate',
            message: 'Scan yer finger'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/signupm"]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    Signup1Component.prototype.toggleDisplayCust = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan yer finger'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/signupc"]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    return Signup1Component;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], Signup1Component.prototype, "container", void 0);
Signup1Component = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/signup1/signup1.html",
        styleUrls: ["./pages/signup1/signup1-common.css", "./pages/signup1/signup1.css"]
    }),
    __metadata("design:paramtypes", [router_1.Router, user_service_1.UserService, page_1.Page])
], Signup1Component);
exports.Signup1Component = Signup1Component;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lnbnVwMS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzaWdudXAxLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5RTtBQUV6RSwrQ0FBOEM7QUFDOUMsK0RBQTZEO0FBQzdELDBDQUd3QjtBQUV4QixnQ0FBK0I7QUFHL0IsK0VBQWdFO0FBUWhFLElBQWEsZ0JBQWdCO0lBVzNCLDBCQUFvQixNQUFjLEVBQVUsV0FBd0IsRUFBVSxJQUFVO1FBQXBFLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBVSxnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQUFVLFNBQUksR0FBSixJQUFJLENBQU07UUFIeEYsZ0JBQVcsR0FBRyxJQUFJLENBQUM7UUFJakIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLFdBQUksRUFBRSxDQUFDO1FBQ3ZCLDBDQUEwQztRQUMxQyxrQ0FBa0M7SUFFcEMsQ0FBQztJQWRDLG1DQUFRLEdBQVI7UUFDSSxtQ0FBbUM7UUFDbkMseUNBQXlDO0lBQzNDLENBQUM7SUFZTCxpQ0FBTSxHQUFOO1FBQ0UsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztRQUFDLElBQUksQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hCLENBQUM7SUFDSCxDQUFDO0lBQ0QsZ0NBQUssR0FBTDtRQUFBLGlCQU1DO1FBTEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUM5QixTQUFTLENBQ1IsY0FBTSxPQUFBLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBL0IsQ0FBK0IsRUFDckMsVUFBQyxLQUFLLElBQUssT0FBQSxLQUFLLENBQUMsK0NBQStDLENBQUMsRUFBdEQsQ0FBc0QsQ0FDbEUsQ0FBQztJQUNOLENBQUM7SUFDRCxpQ0FBTSxHQUFOO1FBQUEsaUJBU0M7UUFSQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2pDLFNBQVMsQ0FDUjtZQUNFLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ2hELEtBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzNCLENBQUMsRUFDRCxjQUFNLE9BQUEsS0FBSyxDQUFDLHNEQUFzRCxDQUFDLEVBQTdELENBQTZELENBQ3BFLENBQUM7SUFDTixDQUFDO0lBQ0QsOENBQW1CLEdBQW5CO1FBQ0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFDRCw0Q0FBaUIsR0FBakI7UUFDRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUNELHdDQUFhLEdBQWI7UUFDRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVELDJDQUFnQixHQUFoQjtRQUNFLElBQUksZUFBZSxHQUFHLElBQUksK0NBQWUsRUFBRSxDQUFDO1FBQzVDLDhCQUE4QjtRQUM5QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsZUFBZSxDQUFDLFNBQVMsRUFBRTthQUMxQixJQUFJLENBQ0gsVUFBQyxLQUFjO1lBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxLQUFPLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQ0YsQ0FBQztRQUNGLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztZQUNoQyxLQUFLLEVBQUUseUJBQXlCO1lBQ2hDLE9BQU8sRUFBRSxpQkFBaUI7U0FDM0IsQ0FBQyxDQUFDLElBQUksQ0FDSDtZQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFDckMsQ0FBQyxFQUNEO1lBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FDSixDQUFBO0lBQ0gsQ0FBQztJQUdELDRDQUFpQixHQUFqQjtRQUNFLElBQUksZUFBZSxHQUFHLElBQUksK0NBQWUsRUFBRSxDQUFDO1FBQzVDLDhCQUE4QjtRQUM5QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsZUFBZSxDQUFDLFNBQVMsRUFBRTthQUMxQixJQUFJLENBQ0gsVUFBQyxLQUFjO1lBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxLQUFPLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQ0YsQ0FBQztRQUNGLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztZQUNoQyxLQUFLLEVBQUUseUJBQXlCO1lBQ2hDLE9BQU8sRUFBRSxpQkFBaUI7U0FDM0IsQ0FBQyxDQUFDLElBQUksQ0FDSDtZQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFDckMsQ0FBQyxFQUNEO1lBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FDSixDQUFBO0lBQ0gsQ0FBQztJQUNILHVCQUFDO0FBQUQsQ0FBQyxBQW5HRCxJQW1HQztBQTFGeUI7SUFBdkIsZ0JBQVMsQ0FBQyxXQUFXLENBQUM7OEJBQVksaUJBQVU7bURBQUM7QUFUbkMsZ0JBQWdCO0lBTjVCLGdCQUFTLENBQUM7UUFDVCxRQUFRLEVBQUUsUUFBUTtRQUNsQixTQUFTLEVBQUUsQ0FBQywwQkFBVyxDQUFDO1FBQ3hCLFdBQVcsRUFBRSw4QkFBOEI7UUFDM0MsU0FBUyxFQUFFLENBQUMsb0NBQW9DLEVBQUUsNkJBQTZCLENBQUM7S0FDakYsQ0FBQztxQ0FZNEIsZUFBTSxFQUF1QiwwQkFBVyxFQUFnQixXQUFJO0dBWDdFLGdCQUFnQixDQW1HNUI7QUFuR1ksNENBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXJcIjtcclxuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlci5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7XHJcbiAgUm91dGVyLFxyXG4gIEV2ZW50IGFzIFJvdXRlckV2ZW50LFxyXG59IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcidcclxuXHJcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xyXG5pbXBvcnQgeyBDb2xvciB9IGZyb20gXCJjb2xvclwiO1xyXG5pbXBvcnQgeyBWaWV3IH0gZnJvbSBcInVpL2NvcmUvdmlld1wiO1xyXG5pbXBvcnQgeyBGaW5nZXJwcmludEF1dGggfSBmcm9tIFwibmF0aXZlc2NyaXB0LWZpbmdlcnByaW50LWF1dGhcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiBcIm15LWFwcFwiLFxyXG4gIHByb3ZpZGVyczogW1VzZXJTZXJ2aWNlXSxcclxuICB0ZW1wbGF0ZVVybDogXCIuL3BhZ2VzL3NpZ251cDEvc2lnbnVwMS5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXCIuL3BhZ2VzL3NpZ251cDEvc2lnbnVwMS1jb21tb24uY3NzXCIsIFwiLi9wYWdlcy9zaWdudXAxL3NpZ251cDEuY3NzXCJdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTaWdudXAxQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICAvL3RoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xyXG4gICAgICAgIC8vdGhpcy5wYWdlLmJhY2tncm91bmRJbWFnZSA9IFwicmVzOi8vYmdcIjtcclxuICAgICAgfVxyXG5cclxuICB1c2VyOiBVc2VyO1xyXG4gIGlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuICBAVmlld0NoaWxkKFwiY29udGFpbmVyXCIpIGNvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSB1c2VyU2VydmljZTogVXNlclNlcnZpY2UsIHByaXZhdGUgcGFnZTogUGFnZSkge1xyXG4gICAgdGhpcy51c2VyID0gbmV3IFVzZXIoKTtcclxuICAgIC8vdGhpcy51c2VyLmVtYWlsID0gXCJ0ZXN0QG1hc3RlcmNhcmQuY29tXCI7XHJcbiAgICAvL3RoaXMudXNlci5wYXNzd29yZCA9IFwicGFzc3dvcmRcIjtcclxuICAgIFxyXG4gIH1cclxuICBzdWJtaXQoKSB7XHJcbiAgICBpZiAodGhpcy5pc0xvZ2dpbmdJbikge1xyXG4gICAgICB0aGlzLmxvZ2luKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnNpZ25VcCgpO1xyXG4gICAgfVxyXG4gIH1cclxuICBsb2dpbigpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UubG9naW4odGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIi9saXN0XCJdKSxcclxuICAgICAgICAoZXJyb3IpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSBjb3VsZCBub3QgZmluZCB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHNpZ25VcCgpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UucmVnaXN0ZXIodGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHtcclxuICAgICAgICAgIGFsZXJ0KFwiWW91ciBhY2NvdW50IHdhcyBzdWNjZXNzZnVsbHkgY3JlYXRlZC5cIik7XHJcbiAgICAgICAgICB0aGlzLnRvZ2dsZURpc3BsYXlDdXN0KCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICAoKSA9PiBhbGVydChcIlVuZm9ydHVuYXRlbHkgd2Ugd2VyZSB1bmFibGUgdG8gY3JlYXRlIHlvdXIgYWNjb3VudC5cIilcclxuICAgICAgKTtcclxuICB9XHJcbiAgdG9nZ2xlRGlzcGxheUN1c3QxMSgpIHtcclxuICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIi9zaWdudXBjXCJdKTtcclxuICB9XHJcbiAgdG9nZ2xlRGlzcGxheU1lcjEoKSB7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvc2lnbnVwbVwiXSk7XHJcbiAgfVxyXG4gIHRvZ2dsZURpc3BsYXkoKSB7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvXCJdKTtcclxuICB9XHJcbiAgXHJcbiAgdG9nZ2xlRGlzcGxheU1lcigpe1xyXG4gICAgbGV0IGZpbmdlcnByaW50QXV0aCA9IG5ldyBGaW5nZXJwcmludEF1dGgoKTtcclxuICAgIC8vdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICBmaW5nZXJwcmludEF1dGguYXZhaWxhYmxlKClcclxuICAgIC50aGVuKFxyXG4gICAgICAoYXZhaWw6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhgQXZhaWxhYmxlPyAke2F2YWlsfWApO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gICAgZmluZ2VycHJpbnRBdXRoLnZlcmlmeUZpbmdlcnByaW50KHtcclxuICAgICAgdGl0bGU6ICdTY2FuIGZpbmdlciB0byB2YWxpZGF0ZScsIC8vIG9wdGlvbmFsIHRpdGxlICh1c2VkIG9ubHkgb24gQW5kcm9pZClcclxuICAgICAgbWVzc2FnZTogJ1NjYW4geWVyIGZpbmdlcidcclxuICAgIH0pLnRoZW4oXHJcbiAgICAgICAgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkZpbmdlcnByaW50IHdhcyBPS1wiKTtcclxuICAgICAgICAgIHNlbGYucm91dGVyLm5hdmlnYXRlKFtcIi9zaWdudXBtXCJdKTsgICAgICAgICAgXHJcbiAgICAgICAgfSxcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgTk9UIE9LXCIpO1xyXG4gICAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIFxyXG4gIHRvZ2dsZURpc3BsYXlDdXN0KCl7XHJcbiAgICBsZXQgZmluZ2VycHJpbnRBdXRoID0gbmV3IEZpbmdlcnByaW50QXV0aCgpO1xyXG4gICAgLy90aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvXCJdKTtcclxuICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgIGZpbmdlcnByaW50QXV0aC5hdmFpbGFibGUoKVxyXG4gICAgLnRoZW4oXHJcbiAgICAgIChhdmFpbDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBBdmFpbGFibGU/ICR7YXZhaWx9YCk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgICBmaW5nZXJwcmludEF1dGgudmVyaWZ5RmluZ2VycHJpbnQoe1xyXG4gICAgICB0aXRsZTogJ1NjYW4gZmluZ2VyIHRvIGNvbnRpbnVlJywgLy8gb3B0aW9uYWwgdGl0bGUgKHVzZWQgb25seSBvbiBBbmRyb2lkKVxyXG4gICAgICBtZXNzYWdlOiAnU2NhbiB5ZXIgZmluZ2VyJ1xyXG4gICAgfSkudGhlbihcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgd2FzIE9LXCIpO1xyXG4gICAgICAgICAgc2VsZi5yb3V0ZXIubmF2aWdhdGUoW1wiL3NpZ251cGNcIl0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkZpbmdlcnByaW50IE5PVCBPS1wiKTtcclxuICAgICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG59Il19