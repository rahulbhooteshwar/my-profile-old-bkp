import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";

import { User } from "../../shared/user/user";
import { UserService } from "../../shared/user/user.service";
import {
  Router,
  Event as RouterEvent,
} from '@angular/router'

import { Page } from "ui/page";
import { Color } from "color";
import { View } from "ui/core/view";
import { FingerprintAuth } from "nativescript-fingerprint-auth";

@Component({
  selector: "my-app",
  providers: [UserService],
  templateUrl: "./pages/signup1/signup1.html",
  styleUrls: ["./pages/signup1/signup1-common.css", "./pages/signup1/signup1.css"]
})
export class Signup1Component implements OnInit {

    ngOnInit() {
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
      }

  user: User;
  isLoggingIn = true;
  @ViewChild("container") container: ElementRef;

  constructor(private router: Router, private userService: UserService, private page: Page) {
    this.user = new User();
    //this.user.email = "test@mastercard.com";
    //this.user.password = "password";
    
  }
  submit() {
    if (this.isLoggingIn) {
      this.login();
    } else {
      this.signUp();
    }
  }
  login() {
    this.userService.login(this.user)
      .subscribe(
        () => this.router.navigate(["/list"]),
        (error) => alert("Unfortunately we could not find your account.")
      );
  }
  signUp() {
    this.userService.register(this.user)
      .subscribe(
        () => {
          alert("Your account was successfully created.");
          this.toggleDisplayCust();
        },
        () => alert("Unfortunately we were unable to create your account.")
      );
  }
  toggleDisplayCust11() {
    this.router.navigate(["/signupc"]);
  }
  toggleDisplayMer1() {
    this.router.navigate(["/signupm"]);
  }
  toggleDisplay() {
    this.router.navigate(["/"]);
  }
  
  toggleDisplayMer(){
    let fingerprintAuth = new FingerprintAuth();
    //this.router.navigate(["/"]);
    let self = this;
    fingerprintAuth.available()
    .then(
      (avail: boolean) => {
        console.log(`Available? ${avail}`);
      }
    );
    fingerprintAuth.verifyFingerprint({
      title: 'Scan finger to validate', // optional title (used only on Android)
      message: 'Scan yer finger'
    }).then(
        function() {
          console.log("Fingerprint was OK");
          self.router.navigate(["/signupm"]);          
        },
        function() {
          console.log("Fingerprint NOT OK");
        }
    )
  }

  
  toggleDisplayCust(){
    let fingerprintAuth = new FingerprintAuth();
    //this.router.navigate(["/"]);
    let self = this;
    fingerprintAuth.available()
    .then(
      (avail: boolean) => {
        console.log(`Available? ${avail}`);
      }
    );
    fingerprintAuth.verifyFingerprint({
      title: 'Scan finger to continue', // optional title (used only on Android)
      message: 'Scan yer finger'
    }).then(
        function() {
          console.log("Fingerprint was OK");
          self.router.navigate(["/signupc"]);
        },
        function() {
          console.log("Fingerprint NOT OK");
        }
    )
  }
}