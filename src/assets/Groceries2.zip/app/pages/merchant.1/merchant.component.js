"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var MerchantComponent = (function () {
    function MerchantComponent(route, router, userService, page) {
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.displayqr = false;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
        this.user.firmname = "Grocery Store";
    }
    MerchantComponent.prototype.toggleQR = function () {
        this.displayqr = !this.displayqr;
    };
    MerchantComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    MerchantComponent.prototype.ngOnInit = function () {
        var _this = this;
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
        this.sub = this.route.params.subscribe(function (params) {
            _this.mername = params['id']; // (+) converts string 'id' to a number
            // In a real app: dispatch action to load the details here.
        });
    };
    MerchantComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    MerchantComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    MerchantComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    MerchantComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    MerchantComponent.prototype.scanFinger = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan yer finger'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/"]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    MerchantComponent.prototype.toggleDisplay1 = function () {
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 500,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            alert({
                title: "Scan result",
                message: "Format: " + result.format + ",\nValue: " + result.text,
                okButtonText: "OK"
            });
        }, function (errorMessage) {
            console.log("No scan. " + errorMessage);
        });
    };
    return MerchantComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], MerchantComponent.prototype, "container", void 0);
MerchantComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/merchant/merchant.html",
        styleUrls: ["./pages/merchant/merchant-common.css", "./pages/merchant/merchant.css"]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService, page_1.Page])
], MerchantComponent);
exports.MerchantComponent = MerchantComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVyY2hhbnQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWVyY2hhbnQuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlFO0FBRXpFLCtDQUE4QztBQUM5QywrREFBNkQ7QUFDN0QsMENBQXlEO0FBQ3pELGdDQUErQjtBQUcvQiw0Q0FBOEM7QUFDOUMsa0NBQWlDO0FBQ2pDLDJFQUE2RDtBQUM3RCwrRUFBZ0U7QUFTaEUsSUFBYSxpQkFBaUI7SUEyQjVCLDJCQUFvQixLQUFxQixFQUFVLE1BQWMsRUFBVSxXQUF3QixFQUFVLElBQVU7UUFBbkcsVUFBSyxHQUFMLEtBQUssQ0FBZ0I7UUFBVSxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQVUsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFNO1FBeEJoSCxjQUFTLEdBQUcsS0FBSyxDQUFDO1FBcUJ6QixnQkFBVyxHQUFHLElBQUksQ0FBQztRQUlqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksV0FBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsNkJBQTZCLENBQUM7UUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztRQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRywrQkFBK0IsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztJQUN2QyxDQUFDO0lBbENELG9DQUFRLEdBQVI7UUFDRSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBRUQsaUNBQUssR0FBTDtRQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUcsb0NBQVEsR0FBUjtRQUFBLGlCQVFHO1FBUEMsbUNBQW1DO1FBQ25DLHlDQUF5QztRQUMzQyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFBLE1BQU07WUFDM0MsS0FBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyx1Q0FBdUM7WUFFdEUsMkRBQTJEO1FBQzlELENBQUMsQ0FBQyxDQUFDO0lBQ0EsQ0FBQztJQW1CTCxrQ0FBTSxHQUFOO1FBQ0UsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztRQUFDLElBQUksQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hCLENBQUM7SUFDSCxDQUFDO0lBQ0QsaUNBQUssR0FBTDtRQUFBLGlCQU1DO1FBTEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUM5QixTQUFTLENBQ1IsY0FBTSxPQUFBLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBL0IsQ0FBK0IsRUFDckMsVUFBQyxLQUFLLElBQUssT0FBQSxLQUFLLENBQUMsK0NBQStDLENBQUMsRUFBdEQsQ0FBc0QsQ0FDbEUsQ0FBQztJQUNOLENBQUM7SUFDRCxrQ0FBTSxHQUFOO1FBQUEsaUJBU0M7UUFSQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2pDLFNBQVMsQ0FDUjtZQUNFLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ2hELEtBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN2QixDQUFDLEVBQ0QsY0FBTSxPQUFBLEtBQUssQ0FBQyxzREFBc0QsQ0FBQyxFQUE3RCxDQUE2RCxDQUNwRSxDQUFDO0lBQ04sQ0FBQztJQUNELHlDQUFhLEdBQWI7UUFDRSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxVQUFDLFVBQVU7WUFDWixPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7WUFDakQsSUFBSSxLQUFLLEdBQUcsSUFBSSxhQUFLLEVBQUUsQ0FBQztZQUN4QixLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO1lBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELHNDQUFVLEdBQVY7UUFDRSxJQUFJLGVBQWUsR0FBRyxJQUFJLCtDQUFlLEVBQUUsQ0FBQztRQUM1Qyw4QkFBOEI7UUFDOUIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLGVBQWUsQ0FBQyxTQUFTLEVBQUU7YUFDMUIsSUFBSSxDQUNILFVBQUMsS0FBYztZQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWMsS0FBTyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUNGLENBQUM7UUFDRixlQUFlLENBQUMsaUJBQWlCLENBQUM7WUFDaEMsS0FBSyxFQUFFLHlCQUF5QjtZQUNoQyxPQUFPLEVBQUUsaUJBQWlCO1NBQzNCLENBQUMsQ0FBQyxJQUFJLENBQ0g7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQzlCLENBQUMsRUFDRDtZQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQ0osQ0FBQTtJQUNILENBQUM7SUFDRCwwQ0FBYyxHQUFkO1FBQ0UsSUFBSSxjQUFjLEdBQUcsSUFBSSw0Q0FBYyxFQUFFLENBQUM7UUFDMUMsY0FBYyxDQUFDLElBQUksQ0FBQztZQUNsQixPQUFPLEVBQUUsaUJBQWlCO1lBQzFCLG9CQUFvQixFQUFFLElBQUk7WUFDMUIsVUFBVSxFQUFFLElBQUk7WUFDaEIsYUFBYSxFQUFFLGNBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBLENBQUEsQ0FBQztZQUNyRCxxQkFBcUIsRUFBRSxHQUFHO1lBQzFCLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLDJDQUEyQyxFQUFFLElBQUk7U0FDbEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLE1BQU07WUFDYiwrRkFBK0Y7WUFDL0YsS0FBSyxDQUFDO2dCQUNKLEtBQUssRUFBRSxhQUFhO2dCQUNwQixPQUFPLEVBQUUsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJO2dCQUNoRSxZQUFZLEVBQUUsSUFBSTthQUNuQixDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsVUFBQyxZQUFZO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUNGLENBQUM7SUFDRixDQUFDO0lBQ0gsd0JBQUM7QUFBRCxDQUFDLEFBeEhELElBd0hDO0FBL0Z5QjtJQUF2QixnQkFBUyxDQUFDLFdBQVcsQ0FBQzs4QkFBWSxpQkFBVTtvREFBQztBQXpCbkMsaUJBQWlCO0lBTjdCLGdCQUFTLENBQUM7UUFDVCxRQUFRLEVBQUUsUUFBUTtRQUNsQixTQUFTLEVBQUUsQ0FBQywwQkFBVyxDQUFDO1FBQ3hCLFdBQVcsRUFBRSxnQ0FBZ0M7UUFDN0MsU0FBUyxFQUFFLENBQUMsc0NBQXNDLEVBQUUsK0JBQStCLENBQUM7S0FDckYsQ0FBQztxQ0E0QjJCLHVCQUFjLEVBQWtCLGVBQU0sRUFBdUIsMEJBQVcsRUFBZ0IsV0FBSTtHQTNCNUcsaUJBQWlCLENBd0g3QjtBQXhIWSw4Q0FBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuXHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlclwiO1xyXG5pbXBvcnQgeyBVc2VyU2VydmljZSB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdXNlci91c2VyLnNlcnZpY2VcIjtcclxuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XHJcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcImNvbG9yXCI7XHJcbmltcG9ydCB7IFZpZXcgfSBmcm9tIFwidWkvY29yZS92aWV3XCI7XHJcbmltcG9ydCAqIGFzIGNhbWVyYSBmcm9tIFwibmF0aXZlc2NyaXB0LWNhbWVyYVwiO1xyXG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJ1aS9pbWFnZVwiO1xyXG5pbXBvcnQgeyBCYXJjb2RlU2Nhbm5lciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYmFyY29kZXNjYW5uZXJcIjtcclxuaW1wb3J0IHsgRmluZ2VycHJpbnRBdXRoIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1maW5nZXJwcmludC1hdXRoXCI7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6IFwibXktYXBwXCIsXHJcbiAgcHJvdmlkZXJzOiBbVXNlclNlcnZpY2VdLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vcGFnZXMvbWVyY2hhbnQvbWVyY2hhbnQuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1wiLi9wYWdlcy9tZXJjaGFudC9tZXJjaGFudC1jb21tb24uY3NzXCIsIFwiLi9wYWdlcy9tZXJjaGFudC9tZXJjaGFudC5jc3NcIl1cclxufSlcclxuZXhwb3J0IGNsYXNzIE1lcmNoYW50Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBtZXJuYW1lOiBzdHJpbmc7XHJcbiAgcHJpdmF0ZSBzdWI6IGFueTtcclxuICBwdWJsaWMgZGlzcGxheXFyID0gZmFsc2U7XHJcblxyXG4gIHRvZ2dsZVFSKCl7XHJcbiAgICB0aGlzLmRpc3BsYXlxciA9ICF0aGlzLmRpc3BsYXlxcjtcclxuICB9XHJcblxyXG4gIG9uVGFwKCkge1xyXG4gICAgY29uc29sZS5sb2coXCJGaXJzdENvbXBvbmVudC5UYXBwZWQhXCIpO1xyXG59XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgLy90aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcclxuICAgICAgICAvL3RoaXMucGFnZS5iYWNrZ3JvdW5kSW1hZ2UgPSBcInJlczovL2JnXCI7XHJcbiAgICAgIHRoaXMuc3ViID0gdGhpcy5yb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKHBhcmFtcyA9PiB7XHJcbiAgICAgICAgdGhpcy5tZXJuYW1lID0gcGFyYW1zWydpZCddOyAvLyAoKykgY29udmVydHMgc3RyaW5nICdpZCcgdG8gYSBudW1iZXJcclxuXHJcbiAgICAgIC8vIEluIGEgcmVhbCBhcHA6IGRpc3BhdGNoIGFjdGlvbiB0byBsb2FkIHRoZSBkZXRhaWxzIGhlcmUuXHJcbiAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gIHVzZXI6IFVzZXI7XHJcbiAgaXNMb2dnaW5nSW4gPSB0cnVlO1xyXG4gIEBWaWV3Q2hpbGQoXCJjb250YWluZXJcIikgY29udGFpbmVyOiBFbGVtZW50UmVmO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSwgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSB1c2VyU2VydmljZTogVXNlclNlcnZpY2UsIHByaXZhdGUgcGFnZTogUGFnZSkge1xyXG4gICAgdGhpcy51c2VyID0gbmV3IFVzZXIoKTtcclxuICAgIHRoaXMudXNlci5lbWFpbCA9IFwidGVzdGN1c3RvbWVyQG1hc3RlcmNhcmQuY29tXCI7XHJcbiAgICB0aGlzLnVzZXIucGFzc3dvcmQgPSBcInBhc3N3b3JkXCI7XHJcbiAgICB0aGlzLnVzZXIuY2l0eSA9IFwiUHVuZVwiO1xyXG4gICAgdGhpcy51c2VyLmxvY2FsaXR5ID0gXCJZZXJ3YWRhXCI7XHJcbiAgICB0aGlzLnVzZXIuZmlyc3RuYW1lID0gXCJTYWNoaW5cIjtcclxuICAgIHRoaXMudXNlci5sYXN0bmFtZSA9IFwiQWdyYXdhbGxhXCI7XHJcbiAgICB0aGlzLnVzZXIuYWRkcmVzcyA9IFwiTWFzdGVyY2FyZCA4dGggZmxvb3IsIFllcndhZGFcIjtcclxuICAgIHRoaXMudXNlci5wb3N0YWxjb2RlID0gXCI0MTEwMDFcIjtcclxuICAgIHRoaXMudXNlci5tb2JpbGUgPSBcIjc3MTEyMjMzNDRcIjtcclxuICAgIHRoaXMudXNlci5maXJtbmFtZSA9IFwiR3JvY2VyeSBTdG9yZVwiO1xyXG4gIH1cclxuICBzdWJtaXQoKSB7XHJcbiAgICBpZiAodGhpcy5pc0xvZ2dpbmdJbikge1xyXG4gICAgICB0aGlzLmxvZ2luKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnNpZ25VcCgpO1xyXG4gICAgfVxyXG4gIH1cclxuICBsb2dpbigpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UubG9naW4odGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIi9saXN0XCJdKSxcclxuICAgICAgICAoZXJyb3IpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSBjb3VsZCBub3QgZmluZCB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHNpZ25VcCgpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UucmVnaXN0ZXIodGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHtcclxuICAgICAgICAgIGFsZXJ0KFwiWW91ciBhY2NvdW50IHdhcyBzdWNjZXNzZnVsbHkgY3JlYXRlZC5cIik7XHJcbiAgICAgICAgICB0aGlzLnRvZ2dsZURpc3BsYXkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgICgpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSB3ZXJlIHVuYWJsZSB0byBjcmVhdGUgeW91ciBhY2NvdW50LlwiKVxyXG4gICAgICApO1xyXG4gIH1cclxuICB0b2dnbGVEaXNwbGF5KCkge1xyXG4gICAgY2FtZXJhLnJlcXVlc3RQZXJtaXNzaW9ucygpO1xyXG4gICAgY2FtZXJhLnRha2VQaWN0dXJlKCkuXHJcbiAgICAgIHRoZW4oKGltYWdlQXNzZXQpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVzdWx0IGlzIGFuIGltYWdlIGFzc2V0IGluc3RhbmNlXCIpO1xyXG4gICAgICAgICAgdmFyIGltYWdlID0gbmV3IEltYWdlKCk7XHJcbiAgICAgICAgICBpbWFnZS5zcmMgPSBpbWFnZUFzc2V0O1xyXG4gICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIC0+IFwiICsgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICB9KTtcclxuICB9XHJcbiAgc2NhbkZpbmdlcigpe1xyXG4gICAgbGV0IGZpbmdlcnByaW50QXV0aCA9IG5ldyBGaW5nZXJwcmludEF1dGgoKTtcclxuICAgIC8vdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICBmaW5nZXJwcmludEF1dGguYXZhaWxhYmxlKClcclxuICAgIC50aGVuKFxyXG4gICAgICAoYXZhaWw6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhgQXZhaWxhYmxlPyAke2F2YWlsfWApO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gICAgZmluZ2VycHJpbnRBdXRoLnZlcmlmeUZpbmdlcnByaW50KHtcclxuICAgICAgdGl0bGU6ICdTY2FuIGZpbmdlciB0byBjb250aW51ZScsIC8vIG9wdGlvbmFsIHRpdGxlICh1c2VkIG9ubHkgb24gQW5kcm9pZClcclxuICAgICAgbWVzc2FnZTogJ1NjYW4geWVyIGZpbmdlcidcclxuICAgIH0pLnRoZW4oXHJcbiAgICAgICAgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkZpbmdlcnByaW50IHdhcyBPS1wiKTtcclxuICAgICAgICAgIHNlbGYucm91dGVyLm5hdmlnYXRlKFtcIi9cIl0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkZpbmdlcnByaW50IE5PVCBPS1wiKTtcclxuICAgICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG4gIHRvZ2dsZURpc3BsYXkxKCkge1xyXG4gICAgbGV0IGJhcmNvZGVzY2FubmVyID0gbmV3IEJhcmNvZGVTY2FubmVyKCk7XHJcbiAgICBiYXJjb2Rlc2Nhbm5lci5zY2FuKHtcclxuICAgICAgZm9ybWF0czogXCJRUl9DT0RFLCBFQU5fMTNcIixcclxuICAgICAgc2hvd0ZsaXBDYW1lcmFCdXR0b246IHRydWUsXHJcbiAgICAgIGJlZXBPblNjYW46IHRydWUsIFxyXG4gICAgICBjbG9zZUNhbGxiYWNrOiAoKSA9PiB7IGNvbnNvbGUubG9nKFwiU2Nhbm5lciBjbG9zZWRcIil9LCBcclxuICAgICAgcmVzdWx0RGlzcGxheUR1cmF0aW9uOiA1MDAsXHJcbiAgICAgIG9yaWVudGF0aW9uOiBcInBvcnRyYWl0XCIsXHJcbiAgICAgIG9wZW5TZXR0aW5nc0lmUGVybWlzc2lvbldhc1ByZXZpb3VzbHlEZW5pZWQ6IHRydWVcclxuICAgIH0pLnRoZW4oKHJlc3VsdCkgPT4geyAgICAgIFxyXG4gICAgICAvLyBOb3RlIHRoYXQgdGhpcyBQcm9taXNlIGlzIG5ldmVyIGludm9rZWQgd2hlbiBhICdjb250aW51b3VzU2NhbkNhbGxiYWNrJyBmdW5jdGlvbiBpcyBwcm92aWRlZFxyXG4gICAgICBhbGVydCh7XHJcbiAgICAgICAgdGl0bGU6IFwiU2NhbiByZXN1bHRcIixcclxuICAgICAgICBtZXNzYWdlOiBcIkZvcm1hdDogXCIgKyByZXN1bHQuZm9ybWF0ICsgXCIsXFxuVmFsdWU6IFwiICsgcmVzdWx0LnRleHQsXHJcbiAgICAgICAgb2tCdXR0b25UZXh0OiBcIk9LXCJcclxuICAgICAgfSk7XHJcbiAgICB9LCAoZXJyb3JNZXNzYWdlKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiTm8gc2Nhbi4gXCIgKyBlcnJvck1lc3NhZ2UpO1xyXG4gICAgfVxyXG4gICk7XHJcbiAgfVxyXG59Il19