"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var CustomerComponent = (function () {
    function CustomerComponent(router, userService, page) {
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.message = "";
        this.displayusers = false;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
    }
    CustomerComponent.prototype.toggleDisplayCust = function () {
        this.displayusers = true;
    };
    CustomerComponent.prototype.home = function () {
        this.displayusers = false;
    };
    CustomerComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    CustomerComponent.prototype.ngOnInit = function () {
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
    };
    CustomerComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    CustomerComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    CustomerComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    CustomerComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    CustomerComponent.prototype.scanFinger = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan yer finger'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/"]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    CustomerComponent.prototype.toggleDisplay1 = function () {
        var _this = this;
        console.log("Hello, world!");
        console.info("I am NativeScript");
        console.warn("Low memory");
        console.error("Uncaught Application Exception");
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 1000,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            _this.message = "Format: " + result.format + ",\nValue: " + result.text;
            console.info("No scan. " + _this.message);
            _this.router.navigate(['confirm', { amount: '', type: 'customer' }]);
        }, function (errorMessage) {
            console.info("No scan. " + errorMessage);
        });
    };
    CustomerComponent.prototype.confirmpay = function () {
        this.router.navigate(['confirm', { amount: this.user.amount, type: 'p2p' }]);
    };
    return CustomerComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], CustomerComponent.prototype, "container", void 0);
CustomerComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/customer/customer.html",
        styleUrls: ["./pages/customer/customer-common.css", "./pages/customer/customer.css"]
    }),
    __metadata("design:paramtypes", [router_1.Router, user_service_1.UserService, page_1.Page])
], CustomerComponent);
exports.CustomerComponent = CustomerComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY3VzdG9tZXIuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlFO0FBRXpFLCtDQUE4QztBQUM5QywrREFBNkQ7QUFDN0QsMENBQXlDO0FBQ3pDLGdDQUErQjtBQUcvQiw0Q0FBOEM7QUFDOUMsa0NBQWlDO0FBQ2pDLDJFQUE2RDtBQUM3RCwrRUFBZ0U7QUFTaEUsSUFBYSxpQkFBaUI7SUF5QjVCLDJCQUFvQixNQUFjLEVBQVUsV0FBd0IsRUFBVSxJQUFVO1FBQXBFLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBVSxnQkFBVyxHQUFYLFdBQVcsQ0FBYTtRQUFVLFNBQUksR0FBSixJQUFJLENBQU07UUF2QnhGLFlBQU8sR0FBRyxFQUFFLENBQUM7UUFDTixpQkFBWSxHQUFHLEtBQUssQ0FBQztRQW1CNUIsZ0JBQVcsR0FBRyxJQUFJLENBQUM7UUFJakIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLFdBQUksRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLDZCQUE2QixDQUFDO1FBQ2hELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7UUFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsK0JBQStCLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQztJQUNsQyxDQUFDO0lBL0JELDZDQUFpQixHQUFqQjtRQUNFLElBQUksQ0FBQyxZQUFZLEdBQUMsSUFBSSxDQUFDO0lBQ3pCLENBQUM7SUFDRCxnQ0FBSSxHQUFKO1FBQ0UsSUFBSSxDQUFDLFlBQVksR0FBQyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUVELGlDQUFLLEdBQUw7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVHLG9DQUFRLEdBQVI7UUFDSSxtQ0FBbUM7UUFDbkMseUNBQXlDO0lBQzNDLENBQUM7SUFrQkwsa0NBQU0sR0FBTjtRQUNFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNOLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQixDQUFDO0lBQ0gsQ0FBQztJQUNELGlDQUFLLEdBQUw7UUFBQSxpQkFNQztRQUxDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDOUIsU0FBUyxDQUNSLGNBQU0sT0FBQSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQS9CLENBQStCLEVBQ3JDLFVBQUMsS0FBSyxJQUFLLE9BQUEsS0FBSyxDQUFDLCtDQUErQyxDQUFDLEVBQXRELENBQXNELENBQ2xFLENBQUM7SUFDTixDQUFDO0lBQ0Qsa0NBQU0sR0FBTjtRQUFBLGlCQVNDO1FBUkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUNqQyxTQUFTLENBQ1I7WUFDRSxLQUFLLENBQUMsd0NBQXdDLENBQUMsQ0FBQztZQUNoRCxLQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkIsQ0FBQyxFQUNELGNBQU0sT0FBQSxLQUFLLENBQUMsc0RBQXNELENBQUMsRUFBN0QsQ0FBNkQsQ0FDcEUsQ0FBQztJQUNOLENBQUM7SUFDRCx5Q0FBYSxHQUFiO1FBQ0UsTUFBTSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDNUIsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUNsQixJQUFJLENBQUMsVUFBQyxVQUFVO1lBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1lBQ2pELElBQUksS0FBSyxHQUFHLElBQUksYUFBSyxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsR0FBRztZQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRCxzQ0FBVSxHQUFWO1FBQ0UsSUFBSSxlQUFlLEdBQUcsSUFBSSwrQ0FBZSxFQUFFLENBQUM7UUFDNUMsOEJBQThCO1FBQzlCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixlQUFlLENBQUMsU0FBUyxFQUFFO2FBQzFCLElBQUksQ0FDSCxVQUFDLEtBQWM7WUFDYixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFjLEtBQU8sQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FDRixDQUFDO1FBQ0YsZUFBZSxDQUFDLGlCQUFpQixDQUFDO1lBQ2hDLEtBQUssRUFBRSx5QkFBeUI7WUFDaEMsT0FBTyxFQUFFLGlCQUFpQjtTQUMzQixDQUFDLENBQUMsSUFBSSxDQUNIO1lBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDLEVBQ0Q7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUNKLENBQUE7SUFDSCxDQUFDO0lBQ0QsMENBQWMsR0FBZDtRQUFBLGlCQXVCQztRQXRCQyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNsQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztRQUNoRCxJQUFJLGNBQWMsR0FBRyxJQUFJLDRDQUFjLEVBQUUsQ0FBQztRQUMxQyxjQUFjLENBQUMsSUFBSSxDQUFDO1lBQ2xCLE9BQU8sRUFBRSxpQkFBaUI7WUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtZQUMxQixVQUFVLEVBQUUsSUFBSTtZQUNoQixhQUFhLEVBQUUsY0FBUSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUEsQ0FBQSxDQUFDO1lBQ3JELHFCQUFxQixFQUFFLElBQUk7WUFDM0IsV0FBVyxFQUFFLFVBQVU7WUFDdkIsMkNBQTJDLEVBQUUsSUFBSTtTQUNsRCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsTUFBTTtZQUNiLCtGQUErRjtZQUMvRixLQUFJLENBQUMsT0FBTyxHQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFBO1lBQ3BFLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN6QyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFDLE1BQU0sRUFBQyxFQUFFLEVBQUMsSUFBSSxFQUFDLFVBQVUsRUFBQyxDQUFDLENBQUMsQ0FBQztRQUNqRSxDQUFDLEVBQUUsVUFBQyxZQUFZO1lBQ2QsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUNGLENBQUM7SUFDRixDQUFDO0lBRUQsc0NBQVUsR0FBVjtRQUNFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUNILHdCQUFDO0FBQUQsQ0FBQyxBQTNIRCxJQTJIQztBQXBHeUI7SUFBdkIsZ0JBQVMsQ0FBQyxXQUFXLENBQUM7OEJBQVksaUJBQVU7b0RBQUM7QUF2Qm5DLGlCQUFpQjtJQU43QixnQkFBUyxDQUFDO1FBQ1QsUUFBUSxFQUFFLFFBQVE7UUFDbEIsU0FBUyxFQUFFLENBQUMsMEJBQVcsQ0FBQztRQUN4QixXQUFXLEVBQUUsZ0NBQWdDO1FBQzdDLFNBQVMsRUFBRSxDQUFDLHNDQUFzQyxFQUFFLCtCQUErQixDQUFDO0tBQ3JGLENBQUM7cUNBMEI0QixlQUFNLEVBQXVCLDBCQUFXLEVBQWdCLFdBQUk7R0F6QjdFLGlCQUFpQixDQTJIN0I7QUEzSFksOENBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXJcIjtcclxuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlci5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XHJcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcImNvbG9yXCI7XHJcbmltcG9ydCB7IFZpZXcgfSBmcm9tIFwidWkvY29yZS92aWV3XCI7XHJcbmltcG9ydCAqIGFzIGNhbWVyYSBmcm9tIFwibmF0aXZlc2NyaXB0LWNhbWVyYVwiO1xyXG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJ1aS9pbWFnZVwiO1xyXG5pbXBvcnQgeyBCYXJjb2RlU2Nhbm5lciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYmFyY29kZXNjYW5uZXJcIjtcclxuaW1wb3J0IHsgRmluZ2VycHJpbnRBdXRoIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1maW5nZXJwcmludC1hdXRoXCI7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6IFwibXktYXBwXCIsXHJcbiAgcHJvdmlkZXJzOiBbVXNlclNlcnZpY2VdLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vcGFnZXMvY3VzdG9tZXIvY3VzdG9tZXIuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1wiLi9wYWdlcy9jdXN0b21lci9jdXN0b21lci1jb21tb24uY3NzXCIsIFwiLi9wYWdlcy9jdXN0b21lci9jdXN0b21lci5jc3NcIl1cclxufSlcclxuZXhwb3J0IGNsYXNzIEN1c3RvbWVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgbWVzc2FnZSA9IFwiXCI7XHJcbiAgcHVibGljIGRpc3BsYXl1c2VycyA9IGZhbHNlO1xyXG5cclxuICB0b2dnbGVEaXNwbGF5Q3VzdCgpIHtcclxuICAgIHRoaXMuZGlzcGxheXVzZXJzPXRydWU7XHJcbiAgfVxyXG4gIGhvbWUoKSB7XHJcbiAgICB0aGlzLmRpc3BsYXl1c2Vycz1mYWxzZTtcclxuICB9XHJcblxyXG4gIG9uVGFwKCkge1xyXG4gICAgY29uc29sZS5sb2coXCJGaXJzdENvbXBvbmVudC5UYXBwZWQhXCIpO1xyXG59XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgLy90aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcclxuICAgICAgICAvL3RoaXMucGFnZS5iYWNrZ3JvdW5kSW1hZ2UgPSBcInJlczovL2JnXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgdXNlcjogVXNlcjtcclxuICBpc0xvZ2dpbmdJbiA9IHRydWU7XHJcbiAgQFZpZXdDaGlsZChcImNvbnRhaW5lclwiKSBjb250YWluZXI6IEVsZW1lbnRSZWY7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgdXNlclNlcnZpY2U6IFVzZXJTZXJ2aWNlLCBwcml2YXRlIHBhZ2U6IFBhZ2UpIHtcclxuICAgIHRoaXMudXNlciA9IG5ldyBVc2VyKCk7XHJcbiAgICB0aGlzLnVzZXIuZW1haWwgPSBcInRlc3RjdXN0b21lckBtYXN0ZXJjYXJkLmNvbVwiO1xyXG4gICAgdGhpcy51c2VyLnBhc3N3b3JkID0gXCJwYXNzd29yZFwiO1xyXG4gICAgdGhpcy51c2VyLmNpdHkgPSBcIlB1bmVcIjtcclxuICAgIHRoaXMudXNlci5sb2NhbGl0eSA9IFwiWWVyd2FkYVwiO1xyXG4gICAgdGhpcy51c2VyLmZpcnN0bmFtZSA9IFwiU2FjaGluXCI7XHJcbiAgICB0aGlzLnVzZXIubGFzdG5hbWUgPSBcIkFncmF3YWxsYVwiO1xyXG4gICAgdGhpcy51c2VyLmFkZHJlc3MgPSBcIk1hc3RlcmNhcmQgOHRoIGZsb29yLCBZZXJ3YWRhXCI7XHJcbiAgICB0aGlzLnVzZXIucG9zdGFsY29kZSA9IFwiNDExMDAxXCI7XHJcbiAgICB0aGlzLnVzZXIubW9iaWxlID0gXCI3NzExMjIzMzQ0XCI7XHJcbiAgfVxyXG4gIHN1Ym1pdCgpIHtcclxuICAgIGlmICh0aGlzLmlzTG9nZ2luZ0luKSB7XHJcbiAgICAgIHRoaXMubG9naW4oKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuc2lnblVwKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGxvZ2luKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5sb2dpbih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4gdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL2xpc3RcIl0pLFxyXG4gICAgICAgIChlcnJvcikgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIGNvdWxkIG5vdCBmaW5kIHlvdXIgYWNjb3VudC5cIilcclxuICAgICAgKTtcclxuICB9XHJcbiAgc2lnblVwKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5yZWdpc3Rlcih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgYWxlcnQoXCJZb3VyIGFjY291bnQgd2FzIHN1Y2Nlc3NmdWxseSBjcmVhdGVkLlwiKTtcclxuICAgICAgICAgIHRoaXMudG9nZ2xlRGlzcGxheSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgKCkgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIHdlcmUgdW5hYmxlIHRvIGNyZWF0ZSB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHRvZ2dsZURpc3BsYXkoKSB7XHJcbiAgICBjYW1lcmEucmVxdWVzdFBlcm1pc3Npb25zKCk7XHJcbiAgICBjYW1lcmEudGFrZVBpY3R1cmUoKS5cclxuICAgICAgdGhlbigoaW1hZ2VBc3NldCkgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJSZXN1bHQgaXMgYW4gaW1hZ2UgYXNzZXQgaW5zdGFuY2VcIik7XHJcbiAgICAgICAgICB2YXIgaW1hZ2UgPSBuZXcgSW1hZ2UoKTtcclxuICAgICAgICAgIGltYWdlLnNyYyA9IGltYWdlQXNzZXQ7XHJcbiAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgLT4gXCIgKyBlcnIubWVzc2FnZSk7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuICBzY2FuRmluZ2VyKCl7XHJcbiAgICBsZXQgZmluZ2VycHJpbnRBdXRoID0gbmV3IEZpbmdlcnByaW50QXV0aCgpO1xyXG4gICAgLy90aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvXCJdKTtcclxuICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgIGZpbmdlcnByaW50QXV0aC5hdmFpbGFibGUoKVxyXG4gICAgLnRoZW4oXHJcbiAgICAgIChhdmFpbDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBBdmFpbGFibGU/ICR7YXZhaWx9YCk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgICBmaW5nZXJwcmludEF1dGgudmVyaWZ5RmluZ2VycHJpbnQoe1xyXG4gICAgICB0aXRsZTogJ1NjYW4gZmluZ2VyIHRvIGNvbnRpbnVlJywgLy8gb3B0aW9uYWwgdGl0bGUgKHVzZWQgb25seSBvbiBBbmRyb2lkKVxyXG4gICAgICBtZXNzYWdlOiAnU2NhbiB5ZXIgZmluZ2VyJ1xyXG4gICAgfSkudGhlbihcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgd2FzIE9LXCIpO1xyXG4gICAgICAgICAgc2VsZi5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgTk9UIE9LXCIpO1xyXG4gICAgICAgIH1cclxuICAgIClcclxuICB9XHJcbiAgdG9nZ2xlRGlzcGxheTEoKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkhlbGxvLCB3b3JsZCFcIik7XHJcbiAgICBjb25zb2xlLmluZm8oXCJJIGFtIE5hdGl2ZVNjcmlwdFwiKTtcclxuICAgIGNvbnNvbGUud2FybihcIkxvdyBtZW1vcnlcIik7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiVW5jYXVnaHQgQXBwbGljYXRpb24gRXhjZXB0aW9uXCIpO1xyXG4gICAgbGV0IGJhcmNvZGVzY2FubmVyID0gbmV3IEJhcmNvZGVTY2FubmVyKCk7XHJcbiAgICBiYXJjb2Rlc2Nhbm5lci5zY2FuKHtcclxuICAgICAgZm9ybWF0czogXCJRUl9DT0RFLCBFQU5fMTNcIixcclxuICAgICAgc2hvd0ZsaXBDYW1lcmFCdXR0b246IHRydWUsXHJcbiAgICAgIGJlZXBPblNjYW46IHRydWUsIFxyXG4gICAgICBjbG9zZUNhbGxiYWNrOiAoKSA9PiB7IGNvbnNvbGUubG9nKFwiU2Nhbm5lciBjbG9zZWRcIil9LCBcclxuICAgICAgcmVzdWx0RGlzcGxheUR1cmF0aW9uOiAxMDAwLFxyXG4gICAgICBvcmllbnRhdGlvbjogXCJwb3J0cmFpdFwiLFxyXG4gICAgICBvcGVuU2V0dGluZ3NJZlBlcm1pc3Npb25XYXNQcmV2aW91c2x5RGVuaWVkOiB0cnVlXHJcbiAgICB9KS50aGVuKChyZXN1bHQpID0+IHsgICAgICBcclxuICAgICAgLy8gTm90ZSB0aGF0IHRoaXMgUHJvbWlzZSBpcyBuZXZlciBpbnZva2VkIHdoZW4gYSAnY29udGludW91c1NjYW5DYWxsYmFjaycgZnVuY3Rpb24gaXMgcHJvdmlkZWRcclxuICAgICAgdGhpcy5tZXNzYWdlPVwiRm9ybWF0OiBcIiArIHJlc3VsdC5mb3JtYXQgKyBcIixcXG5WYWx1ZTogXCIgKyByZXN1bHQudGV4dFxyXG4gICAgICBjb25zb2xlLmluZm8oXCJObyBzY2FuLiBcIiArIHRoaXMubWVzc2FnZSk7XHJcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnY29uZmlybScsIHthbW91bnQ6JycsdHlwZTonY3VzdG9tZXInfV0pO1xyXG4gICAgfSwgKGVycm9yTWVzc2FnZSkgPT4ge1xyXG4gICAgICBjb25zb2xlLmluZm8oXCJObyBzY2FuLiBcIiArIGVycm9yTWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgKTtcclxuICB9XHJcblxyXG4gIGNvbmZpcm1wYXkoKSB7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJ2NvbmZpcm0nLCB7YW1vdW50OnRoaXMudXNlci5hbW91bnQsdHlwZToncDJwJ31dKTtcclxuICB9XHJcbn0iXX0=