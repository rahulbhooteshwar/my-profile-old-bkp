import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";

import { User } from "../../shared/user/user";
import { UserService } from "../../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "ui/page";
import { Color } from "color";
import { View } from "ui/core/view";
import * as camera from "nativescript-camera";
import { Image } from "ui/image";
import { BarcodeScanner } from "nativescript-barcodescanner";
import { FingerprintAuth } from "nativescript-fingerprint-auth";


@Component({
  selector: "my-app",
  providers: [UserService],
  templateUrl: "./pages/customer/customer.html",
  styleUrls: ["./pages/customer/customer-common.css", "./pages/customer/customer.css"]
})
export class CustomerComponent implements OnInit {

  message = "";
  public displayusers = false;

  toggleDisplayCust() {
    this.displayusers=true;
  }
  home() {
    this.displayusers=false;
  }

  onTap() {
    console.log("FirstComponent.Tapped!");
}

    ngOnInit() {
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
      }

  user: User;
  isLoggingIn = true;
  @ViewChild("container") container: ElementRef;

  constructor(private router: Router, private userService: UserService, private page: Page) {
    this.user = new User();
    this.user.email = "testcustomer@mastercard.com";
    this.user.password = "password";
    this.user.city = "Pune";
    this.user.locality = "Yerwada";
    this.user.firstname = "Sachin";
    this.user.lastname = "Agrawalla";
    this.user.address = "Mastercard 8th floor, Yerwada";
    this.user.postalcode = "411001";
    this.user.mobile = "7711223344";
  }
  submit() {
    if (this.isLoggingIn) {
      this.login();
    } else {
      this.signUp();
    }
  }
  login() {
    this.userService.login(this.user)
      .subscribe(
        () => this.router.navigate(["/list"]),
        (error) => alert("Unfortunately we could not find your account.")
      );
  }
  signUp() {
    this.userService.register(this.user)
      .subscribe(
        () => {
          alert("Your account was successfully created.");
          this.toggleDisplay();
        },
        () => alert("Unfortunately we were unable to create your account.")
      );
  }
  toggleDisplay() {
    camera.requestPermissions();
    camera.takePicture().
      then((imageAsset) => {
          console.log("Result is an image asset instance");
          var image = new Image();
          image.src = imageAsset;
      }).catch((err) => {
          console.log("Error -> " + err.message);
      });
  }
  scanFinger(){
    let fingerprintAuth = new FingerprintAuth();
    //this.router.navigate(["/"]);
    let self = this;
    fingerprintAuth.available()
    .then(
      (avail: boolean) => {
        console.log(`Available? ${avail}`);
      }
    );
    fingerprintAuth.verifyFingerprint({
      title: 'Scan finger to continue', // optional title (used only on Android)
      message: 'Scan yer finger'
    }).then(
        function() {
          console.log("Fingerprint was OK");
          self.router.navigate(["/"]);
        },
        function() {
          console.log("Fingerprint NOT OK");
        }
    )
  }
  toggleDisplay1() {
    console.log("Hello, world!");
    console.info("I am NativeScript");
    console.warn("Low memory");
    console.error("Uncaught Application Exception");
    let barcodescanner = new BarcodeScanner();
    barcodescanner.scan({
      formats: "QR_CODE, EAN_13",
      showFlipCameraButton: true,
      beepOnScan: true, 
      closeCallback: () => { console.log("Scanner closed")}, 
      resultDisplayDuration: 1000,
      orientation: "portrait",
      openSettingsIfPermissionWasPreviouslyDenied: true
    }).then((result) => {      
      // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
      this.message="Format: " + result.format + ",\nValue: " + result.text
      console.info("No scan. " + this.message);
      this.router.navigate(['confirm', {amount:'',type:'customer'}]);
    }, (errorMessage) => {
      console.info("No scan. " + errorMessage);
    }
  );
  }

  confirmpay() {
    this.router.navigate(['confirm', {amount:this.user.amount,type:'p2p'}]);
  }
}