"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var ConfirmComponent = (function () {
    function ConfirmComponent(route, router, userService, page) {
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.displayqr = false;
        this.displayaadhaar = false;
        this.p2p = false;
        this.isLoading = true;
        this.np2p = false;
        this.ap2p = false;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
        this.user.firmname = "Grocery Store";
        this.aadhaar = '2342';
        this.fullname = this.user.firstname + " " + this.user.lastname;
    }
    ConfirmComponent.prototype.toggleQR = function () {
        this.displayqr = !this.displayqr;
    };
    ConfirmComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    ConfirmComponent.prototype.ngOnInit = function () {
        var _this = this;
        //let isLoading = true;
        setTimeout(function () {
            _this.isLoading = false;
            if (_this.p2p) {
                _this.ap2p = true;
                _this.np2p = false;
            }
            else {
                _this.ap2p = false;
                _this.np2p = true;
            }
        }, 4000);
        this.route.params.forEach(function (urlParams) {
            _this.amount = urlParams['amount'];
            _this.type = urlParams['type'];
            if (_this.type == 'merchant') {
                _this.displayaadhaar = true;
                _this.user.amount = _this.amount;
            }
            else if (_this.type == 'customer') {
                _this.displayaadhaar = false;
                _this.merchantname = "Grocery Store";
                _this.location = "Yerwada, Airport Road, Pune";
                _this.user.amount = "";
            }
            else {
                _this.user.amount = _this.amount;
                _this.fullname = "Devang Singh";
                _this.p2p = true;
            }
        });
    };
    ConfirmComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    ConfirmComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    ConfirmComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    ConfirmComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    ConfirmComponent.prototype.scanpay = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan your finger to pay'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/success", { amount: self.user.amount, type: self.type }]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    ConfirmComponent.prototype.toggleDisplay1 = function () {
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 500,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            alert({
                title: "Scan result",
                message: "Format: " + result.format + ",\nValue: " + result.text,
                okButtonText: "OK"
            });
        }, function (errorMessage) {
            console.log("No scan. " + errorMessage);
        });
    };
    return ConfirmComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], ConfirmComponent.prototype, "container", void 0);
ConfirmComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/confirm/confirm.html",
        styleUrls: ["./pages/confirm/confirm-common.css", "./pages/confirm/confirm.css"]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService, page_1.Page])
], ConfirmComponent);
exports.ConfirmComponent = ConfirmComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlybS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25maXJtLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5RTtBQUV6RSwrQ0FBOEM7QUFDOUMsK0RBQTZEO0FBQzdELDBDQUF5RDtBQUN6RCxnQ0FBK0I7QUFHL0IsNENBQThDO0FBQzlDLGtDQUFpQztBQUNqQywyRUFBNkQ7QUFDN0QsK0VBQWdFO0FBU2hFLElBQWEsZ0JBQWdCO0lBNkQzQiwwQkFBb0IsS0FBcUIsRUFBVSxNQUFjLEVBQVUsV0FBd0IsRUFBVSxJQUFVO1FBQW5HLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQVUsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQVUsU0FBSSxHQUFKLElBQUksQ0FBTTtRQXJEaEgsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUNsQixtQkFBYyxHQUFHLEtBQUssQ0FBQztRQUN2QixRQUFHLEdBQUcsS0FBSyxDQUFDO1FBQ1osY0FBUyxHQUFHLElBQUksQ0FBQztRQUNqQixTQUFJLEdBQUcsS0FBSyxDQUFDO1FBQ2IsU0FBSSxHQUFHLEtBQUssQ0FBQztRQTZDcEIsZ0JBQVcsR0FBRyxJQUFJLENBQUM7UUFJakIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLFdBQUksRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLDZCQUE2QixDQUFDO1FBQ2hELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7UUFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsK0JBQStCLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7UUFDckMsSUFBSSxDQUFDLE9BQU8sR0FBQyxNQUFNLENBQUM7UUFDcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDakUsQ0FBQztJQTVERCxtQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUVELGdDQUFLLEdBQUw7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVHLG1DQUFRLEdBQVI7UUFBQSxpQkFnQ0M7UUE5QkMsdUJBQXVCO1FBQ3ZCLFVBQVUsQ0FBQztZQUNULEtBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFBO1lBQ3RCLEVBQUUsQ0FBQSxDQUFDLEtBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNaLEtBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixLQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztZQUNwQixDQUFDO1lBQUMsSUFBSSxDQUFFLENBQUM7Z0JBQ1AsS0FBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7Z0JBQ2xCLEtBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ25CLENBQUM7UUFDSCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFVCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBQyxTQUFTO1lBQ2xDLEtBQUksQ0FBQyxNQUFNLEdBQUUsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2pDLEtBQUksQ0FBQyxJQUFJLEdBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVCLEVBQUUsQ0FBQSxDQUFDLEtBQUksQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLENBQUEsQ0FBQztnQkFDMUIsS0FBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUksQ0FBQyxNQUFNLENBQUM7WUFDakMsQ0FBQztZQUFDLElBQUksQ0FBQyxFQUFFLENBQUEsQ0FBQyxLQUFJLENBQUMsSUFBSSxJQUFJLFVBQVUsQ0FBQyxDQUFBLENBQUM7Z0JBQ2pDLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2dCQUM1QixLQUFJLENBQUMsWUFBWSxHQUFHLGVBQWUsQ0FBQztnQkFDcEMsS0FBSSxDQUFDLFFBQVEsR0FBRyw2QkFBNkIsQ0FBQztnQkFDOUMsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLENBQUM7WUFBQyxJQUFJLENBQUMsQ0FBQztnQkFDTixLQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFJLENBQUMsTUFBTSxDQUFDO2dCQUUvQixLQUFJLENBQUMsUUFBUSxHQUFHLGNBQWMsQ0FBQztnQkFDL0IsS0FBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDbEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQXFCSCxpQ0FBTSxHQUFOO1FBQ0UsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztRQUFDLElBQUksQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hCLENBQUM7SUFDSCxDQUFDO0lBQ0QsZ0NBQUssR0FBTDtRQUFBLGlCQU1DO1FBTEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUM5QixTQUFTLENBQ1IsY0FBTSxPQUFBLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBL0IsQ0FBK0IsRUFDckMsVUFBQyxLQUFLLElBQUssT0FBQSxLQUFLLENBQUMsK0NBQStDLENBQUMsRUFBdEQsQ0FBc0QsQ0FDbEUsQ0FBQztJQUNOLENBQUM7SUFDRCxpQ0FBTSxHQUFOO1FBQUEsaUJBU0M7UUFSQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2pDLFNBQVMsQ0FDUjtZQUNFLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ2hELEtBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN2QixDQUFDLEVBQ0QsY0FBTSxPQUFBLEtBQUssQ0FBQyxzREFBc0QsQ0FBQyxFQUE3RCxDQUE2RCxDQUNwRSxDQUFDO0lBQ04sQ0FBQztJQUNELHdDQUFhLEdBQWI7UUFDRSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxVQUFDLFVBQVU7WUFDWixPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7WUFDakQsSUFBSSxLQUFLLEdBQUcsSUFBSSxhQUFLLEVBQUUsQ0FBQztZQUN4QixLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO1lBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELGtDQUFPLEdBQVA7UUFDRSxJQUFJLGVBQWUsR0FBRyxJQUFJLCtDQUFlLEVBQUUsQ0FBQztRQUM1Qyw4QkFBOEI7UUFDOUIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLGVBQWUsQ0FBQyxTQUFTLEVBQUU7YUFDMUIsSUFBSSxDQUNILFVBQUMsS0FBYztZQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWMsS0FBTyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUNGLENBQUM7UUFDRixlQUFlLENBQUMsaUJBQWlCLENBQUM7WUFDaEMsS0FBSyxFQUFFLHlCQUF5QjtZQUNoQyxPQUFPLEVBQUUseUJBQXlCO1NBQ25DLENBQUMsQ0FBQyxJQUFJLENBQ0g7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEYsQ0FBQyxFQUNEO1lBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FDSixDQUFBO0lBQ0gsQ0FBQztJQUNELHlDQUFjLEdBQWQ7UUFDRSxJQUFJLGNBQWMsR0FBRyxJQUFJLDRDQUFjLEVBQUUsQ0FBQztRQUMxQyxjQUFjLENBQUMsSUFBSSxDQUFDO1lBQ2xCLE9BQU8sRUFBRSxpQkFBaUI7WUFDMUIsb0JBQW9CLEVBQUUsSUFBSTtZQUMxQixVQUFVLEVBQUUsSUFBSTtZQUNoQixhQUFhLEVBQUUsY0FBUSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUEsQ0FBQSxDQUFDO1lBQ3JELHFCQUFxQixFQUFFLEdBQUc7WUFDMUIsV0FBVyxFQUFFLFVBQVU7WUFDdkIsMkNBQTJDLEVBQUUsSUFBSTtTQUNsRCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsTUFBTTtZQUNiLCtGQUErRjtZQUMvRixLQUFLLENBQUM7Z0JBQ0osS0FBSyxFQUFFLGFBQWE7Z0JBQ3BCLE9BQU8sRUFBRSxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sR0FBRyxZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUk7Z0JBQ2hFLFlBQVksRUFBRSxJQUFJO2FBQ25CLENBQUMsQ0FBQztRQUNMLENBQUMsRUFBRSxVQUFDLFlBQVk7WUFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUMxQyxDQUFDLENBQ0YsQ0FBQztJQUNGLENBQUM7SUFDSCx1QkFBQztBQUFELENBQUMsQUE1SkQsSUE0SkM7QUFqR3lCO0lBQXZCLGdCQUFTLENBQUMsV0FBVyxDQUFDOzhCQUFZLGlCQUFVO21EQUFDO0FBM0RuQyxnQkFBZ0I7SUFONUIsZ0JBQVMsQ0FBQztRQUNULFFBQVEsRUFBRSxRQUFRO1FBQ2xCLFNBQVMsRUFBRSxDQUFDLDBCQUFXLENBQUM7UUFDeEIsV0FBVyxFQUFFLDhCQUE4QjtRQUMzQyxTQUFTLEVBQUUsQ0FBQyxvQ0FBb0MsRUFBRSw2QkFBNkIsQ0FBQztLQUNqRixDQUFDO3FDQThEMkIsdUJBQWMsRUFBa0IsZUFBTSxFQUF1QiwwQkFBVyxFQUFnQixXQUFJO0dBN0Q1RyxnQkFBZ0IsQ0E0SjVCO0FBNUpZLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgT25Jbml0LCBWaWV3Q2hpbGQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdXNlci91c2VyXCI7XHJcbmltcG9ydCB7IFVzZXJTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXIuc2VydmljZVwiO1xyXG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xyXG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcclxuaW1wb3J0IHsgQ29sb3IgfSBmcm9tIFwiY29sb3JcIjtcclxuaW1wb3J0IHsgVmlldyB9IGZyb20gXCJ1aS9jb3JlL3ZpZXdcIjtcclxuaW1wb3J0ICogYXMgY2FtZXJhIGZyb20gXCJuYXRpdmVzY3JpcHQtY2FtZXJhXCI7XHJcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcInVpL2ltYWdlXCI7XHJcbmltcG9ydCB7IEJhcmNvZGVTY2FubmVyIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1iYXJjb2Rlc2Nhbm5lclwiO1xyXG5pbXBvcnQgeyBGaW5nZXJwcmludEF1dGggfSBmcm9tIFwibmF0aXZlc2NyaXB0LWZpbmdlcnByaW50LWF1dGhcIjtcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJteS1hcHBcIixcclxuICBwcm92aWRlcnM6IFtVc2VyU2VydmljZV0sXHJcbiAgdGVtcGxhdGVVcmw6IFwiLi9wYWdlcy9jb25maXJtL2NvbmZpcm0uaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1wiLi9wYWdlcy9jb25maXJtL2NvbmZpcm0tY29tbW9uLmNzc1wiLCBcIi4vcGFnZXMvY29uZmlybS9jb25maXJtLmNzc1wiXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ29uZmlybUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgZnVsbG5hbWU6IHN0cmluZztcclxuICBtZXJjaGFudG5hbWU6IHN0cmluZztcclxuICBsb2NhdGlvbjogc3RyaW5nO1xyXG4gIGFtb3VudDogc3RyaW5nO1xyXG4gIGFhZGhhYXI6IHN0cmluZztcclxuICB0eXBlOiBzdHJpbmc7XHJcbiAgcHJpdmF0ZSBzdWI6IGFueTtcclxuICBwdWJsaWMgZGlzcGxheXFyID0gZmFsc2U7XHJcbiAgcHVibGljIGRpc3BsYXlhYWRoYWFyID0gZmFsc2U7XHJcbiAgcHVibGljIHAycCA9IGZhbHNlO1xyXG4gIHB1YmxpYyBpc0xvYWRpbmcgPSB0cnVlO1xyXG4gIHB1YmxpYyBucDJwID0gZmFsc2U7XHJcbiAgcHVibGljIGFwMnAgPSBmYWxzZTtcclxuXHJcbiAgdG9nZ2xlUVIoKXtcclxuICAgIHRoaXMuZGlzcGxheXFyID0gIXRoaXMuZGlzcGxheXFyO1xyXG4gIH1cclxuXHJcbiAgb25UYXAoKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkZpcnN0Q29tcG9uZW50LlRhcHBlZCFcIik7XHJcbn1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgXHJcbiAgICAgIC8vbGV0IGlzTG9hZGluZyA9IHRydWU7XHJcbiAgICAgIHNldFRpbWVvdXQoKCk9PntcclxuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlXHJcbiAgICAgICAgaWYodGhpcy5wMnApIHtcclxuICAgICAgICAgIHRoaXMuYXAycCA9IHRydWU7XHJcbiAgICAgICAgICB0aGlzLm5wMnAgPSBmYWxzZTtcclxuICAgICAgICB9IGVsc2UgIHtcclxuICAgICAgICAgIHRoaXMuYXAycCA9IGZhbHNlO1xyXG4gICAgICAgICAgdGhpcy5ucDJwID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sIDQwMDApO1xyXG4gICAgICBcclxuICAgICAgdGhpcy5yb3V0ZS5wYXJhbXMuZm9yRWFjaCgodXJsUGFyYW1zKSA9PiB7XHJcbiAgICAgICAgdGhpcy5hbW91bnQ9IHVybFBhcmFtc1snYW1vdW50J107XHJcbiAgICAgICAgdGhpcy50eXBlPXVybFBhcmFtc1sndHlwZSddO1xyXG4gICAgICAgIGlmKHRoaXMudHlwZSA9PSAnbWVyY2hhbnQnKXtcclxuICAgICAgICAgIHRoaXMuZGlzcGxheWFhZGhhYXIgPSB0cnVlO1xyXG4gICAgICAgICAgdGhpcy51c2VyLmFtb3VudCA9IHRoaXMuYW1vdW50O1xyXG4gICAgICAgIH0gZWxzZSBpZih0aGlzLnR5cGUgPT0gJ2N1c3RvbWVyJyl7XHJcbiAgICAgICAgICB0aGlzLmRpc3BsYXlhYWRoYWFyID0gZmFsc2U7XHJcbiAgICAgICAgICB0aGlzLm1lcmNoYW50bmFtZSA9IFwiR3JvY2VyeSBTdG9yZVwiO1xyXG4gICAgICAgICAgdGhpcy5sb2NhdGlvbiA9IFwiWWVyd2FkYSwgQWlycG9ydCBSb2FkLCBQdW5lXCI7XHJcbiAgICAgICAgICB0aGlzLnVzZXIuYW1vdW50ID0gXCJcIjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy51c2VyLmFtb3VudCA9IHRoaXMuYW1vdW50O1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICB0aGlzLmZ1bGxuYW1lID0gXCJEZXZhbmcgU2luZ2hcIjtcclxuICAgICAgICAgIHRoaXMucDJwID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICB1c2VyOiBVc2VyO1xyXG4gIGlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuICBAVmlld0NoaWxkKFwiY29udGFpbmVyXCIpIGNvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgdXNlclNlcnZpY2U6IFVzZXJTZXJ2aWNlLCBwcml2YXRlIHBhZ2U6IFBhZ2UpIHtcclxuICAgIHRoaXMudXNlciA9IG5ldyBVc2VyKCk7XHJcbiAgICB0aGlzLnVzZXIuZW1haWwgPSBcInRlc3RjdXN0b21lckBtYXN0ZXJjYXJkLmNvbVwiO1xyXG4gICAgdGhpcy51c2VyLnBhc3N3b3JkID0gXCJwYXNzd29yZFwiO1xyXG4gICAgdGhpcy51c2VyLmNpdHkgPSBcIlB1bmVcIjtcclxuICAgIHRoaXMudXNlci5sb2NhbGl0eSA9IFwiWWVyd2FkYVwiO1xyXG4gICAgdGhpcy51c2VyLmZpcnN0bmFtZSA9IFwiU2FjaGluXCI7XHJcbiAgICB0aGlzLnVzZXIubGFzdG5hbWUgPSBcIkFncmF3YWxsYVwiO1xyXG4gICAgdGhpcy51c2VyLmFkZHJlc3MgPSBcIk1hc3RlcmNhcmQgOHRoIGZsb29yLCBZZXJ3YWRhXCI7XHJcbiAgICB0aGlzLnVzZXIucG9zdGFsY29kZSA9IFwiNDExMDAxXCI7XHJcbiAgICB0aGlzLnVzZXIubW9iaWxlID0gXCI3NzExMjIzMzQ0XCI7XHJcbiAgICB0aGlzLnVzZXIuZmlybW5hbWUgPSBcIkdyb2NlcnkgU3RvcmVcIjtcclxuICAgIHRoaXMuYWFkaGFhcj0nMjM0Mic7XHJcbiAgICB0aGlzLmZ1bGxuYW1lID0gdGhpcy51c2VyLmZpcnN0bmFtZSArIFwiIFwiICsgdGhpcy51c2VyLmxhc3RuYW1lO1xyXG4gIH1cclxuICBzdWJtaXQoKSB7XHJcbiAgICBpZiAodGhpcy5pc0xvZ2dpbmdJbikge1xyXG4gICAgICB0aGlzLmxvZ2luKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnNpZ25VcCgpO1xyXG4gICAgfVxyXG4gIH1cclxuICBsb2dpbigpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UubG9naW4odGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIi9saXN0XCJdKSxcclxuICAgICAgICAoZXJyb3IpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSBjb3VsZCBub3QgZmluZCB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHNpZ25VcCgpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UucmVnaXN0ZXIodGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHtcclxuICAgICAgICAgIGFsZXJ0KFwiWW91ciBhY2NvdW50IHdhcyBzdWNjZXNzZnVsbHkgY3JlYXRlZC5cIik7XHJcbiAgICAgICAgICB0aGlzLnRvZ2dsZURpc3BsYXkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgICgpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSB3ZXJlIHVuYWJsZSB0byBjcmVhdGUgeW91ciBhY2NvdW50LlwiKVxyXG4gICAgICApO1xyXG4gIH1cclxuICB0b2dnbGVEaXNwbGF5KCkge1xyXG4gICAgY2FtZXJhLnJlcXVlc3RQZXJtaXNzaW9ucygpO1xyXG4gICAgY2FtZXJhLnRha2VQaWN0dXJlKCkuXHJcbiAgICAgIHRoZW4oKGltYWdlQXNzZXQpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVzdWx0IGlzIGFuIGltYWdlIGFzc2V0IGluc3RhbmNlXCIpO1xyXG4gICAgICAgICAgdmFyIGltYWdlID0gbmV3IEltYWdlKCk7XHJcbiAgICAgICAgICBpbWFnZS5zcmMgPSBpbWFnZUFzc2V0O1xyXG4gICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIC0+IFwiICsgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICB9KTtcclxuICB9XHJcbiAgc2NhbnBheSgpe1xyXG4gICAgbGV0IGZpbmdlcnByaW50QXV0aCA9IG5ldyBGaW5nZXJwcmludEF1dGgoKTtcclxuICAgIC8vdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICBmaW5nZXJwcmludEF1dGguYXZhaWxhYmxlKClcclxuICAgIC50aGVuKFxyXG4gICAgICAoYXZhaWw6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhgQXZhaWxhYmxlPyAke2F2YWlsfWApO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gICAgZmluZ2VycHJpbnRBdXRoLnZlcmlmeUZpbmdlcnByaW50KHtcclxuICAgICAgdGl0bGU6ICdTY2FuIGZpbmdlciB0byBjb250aW51ZScsIC8vIG9wdGlvbmFsIHRpdGxlICh1c2VkIG9ubHkgb24gQW5kcm9pZClcclxuICAgICAgbWVzc2FnZTogJ1NjYW4geW91ciBmaW5nZXIgdG8gcGF5J1xyXG4gICAgfSkudGhlbihcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgd2FzIE9LXCIpO1xyXG4gICAgICAgICAgc2VsZi5yb3V0ZXIubmF2aWdhdGUoW1wiL3N1Y2Nlc3NcIiwge2Ftb3VudDpzZWxmLnVzZXIuYW1vdW50LCB0eXBlOnNlbGYudHlwZX1dKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJGaW5nZXJwcmludCBOT1QgT0tcIik7XHJcbiAgICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuICB0b2dnbGVEaXNwbGF5MSgpIHtcclxuICAgIGxldCBiYXJjb2Rlc2Nhbm5lciA9IG5ldyBCYXJjb2RlU2Nhbm5lcigpO1xyXG4gICAgYmFyY29kZXNjYW5uZXIuc2Nhbih7XHJcbiAgICAgIGZvcm1hdHM6IFwiUVJfQ09ERSwgRUFOXzEzXCIsXHJcbiAgICAgIHNob3dGbGlwQ2FtZXJhQnV0dG9uOiB0cnVlLFxyXG4gICAgICBiZWVwT25TY2FuOiB0cnVlLCBcclxuICAgICAgY2xvc2VDYWxsYmFjazogKCkgPT4geyBjb25zb2xlLmxvZyhcIlNjYW5uZXIgY2xvc2VkXCIpfSwgXHJcbiAgICAgIHJlc3VsdERpc3BsYXlEdXJhdGlvbjogNTAwLFxyXG4gICAgICBvcmllbnRhdGlvbjogXCJwb3J0cmFpdFwiLFxyXG4gICAgICBvcGVuU2V0dGluZ3NJZlBlcm1pc3Npb25XYXNQcmV2aW91c2x5RGVuaWVkOiB0cnVlXHJcbiAgICB9KS50aGVuKChyZXN1bHQpID0+IHsgICAgICBcclxuICAgICAgLy8gTm90ZSB0aGF0IHRoaXMgUHJvbWlzZSBpcyBuZXZlciBpbnZva2VkIHdoZW4gYSAnY29udGludW91c1NjYW5DYWxsYmFjaycgZnVuY3Rpb24gaXMgcHJvdmlkZWRcclxuICAgICAgYWxlcnQoe1xyXG4gICAgICAgIHRpdGxlOiBcIlNjYW4gcmVzdWx0XCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGb3JtYXQ6IFwiICsgcmVzdWx0LmZvcm1hdCArIFwiLFxcblZhbHVlOiBcIiArIHJlc3VsdC50ZXh0LFxyXG4gICAgICAgIG9rQnV0dG9uVGV4dDogXCJPS1wiXHJcbiAgICAgIH0pO1xyXG4gICAgfSwgKGVycm9yTWVzc2FnZSkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIk5vIHNjYW4uIFwiICsgZXJyb3JNZXNzYWdlKTtcclxuICAgIH1cclxuICApO1xyXG4gIH1cclxufSJdfQ==