"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var MerchantComponent = (function () {
    function MerchantComponent(route, router, userService, page) {
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.displayqr = false;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
        this.user.firmname = "Grocery Store";
    }
    MerchantComponent.prototype.payment = function () {
        this.router.navigate(['confirm', { amount: this.user.amount, type: 'merchant' }]);
    };
    MerchantComponent.prototype.toggleQR = function () {
        this.displayqr = !this.displayqr;
    };
    MerchantComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    MerchantComponent.prototype.ngOnInit = function () {
        var _this = this;
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
        this.sub = this.route.params.subscribe(function (params) {
            _this.mername = params['id']; // (+) converts string 'id' to a number
            // In a real app: dispatch action to load the details here.
        });
    };
    MerchantComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    MerchantComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    MerchantComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    MerchantComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    MerchantComponent.prototype.scanFinger = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan yer finger'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/"]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    MerchantComponent.prototype.toggleDisplay1 = function () {
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 500,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            alert({
                title: "Scan result",
                message: "Format: " + result.format + ",\nValue: " + result.text,
                okButtonText: "OK"
            });
        }, function (errorMessage) {
            console.log("No scan. " + errorMessage);
        });
    };
    return MerchantComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], MerchantComponent.prototype, "container", void 0);
MerchantComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/merchant/merchant.html",
        styleUrls: ["./pages/merchant/merchant-common.css", "./pages/merchant/merchant.css"]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService, page_1.Page])
], MerchantComponent);
exports.MerchantComponent = MerchantComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVyY2hhbnQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWVyY2hhbnQuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlFO0FBRXpFLCtDQUE4QztBQUM5QywrREFBNkQ7QUFDN0QsMENBQXlEO0FBQ3pELGdDQUErQjtBQUcvQiw0Q0FBOEM7QUFDOUMsa0NBQWlDO0FBQ2pDLDJFQUE2RDtBQUM3RCwrRUFBZ0U7QUFTaEUsSUFBYSxpQkFBaUI7SUFnQzVCLDJCQUFvQixLQUFxQixFQUFVLE1BQWMsRUFBVSxXQUF3QixFQUFVLElBQVU7UUFBbkcsVUFBSyxHQUFMLEtBQUssQ0FBZ0I7UUFBVSxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQVUsZ0JBQVcsR0FBWCxXQUFXLENBQWE7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFNO1FBN0JoSCxjQUFTLEdBQUcsS0FBSyxDQUFDO1FBMEJ6QixnQkFBVyxHQUFHLElBQUksQ0FBQztRQUlqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksV0FBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsNkJBQTZCLENBQUM7UUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztRQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRywrQkFBK0IsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztJQUN2QyxDQUFDO0lBdkNELG1DQUFPLEdBQVA7UUFFRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBQyxJQUFJLEVBQUMsVUFBVSxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFRCxvQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUVELGlDQUFLLEdBQUw7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVHLG9DQUFRLEdBQVI7UUFBQSxpQkFRRztRQVBDLG1DQUFtQztRQUNuQyx5Q0FBeUM7UUFDM0MsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBQSxNQUFNO1lBQzNDLEtBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsdUNBQXVDO1lBRXRFLDJEQUEyRDtRQUM5RCxDQUFDLENBQUMsQ0FBQztJQUNBLENBQUM7SUFtQkwsa0NBQU0sR0FBTjtRQUNFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNOLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQixDQUFDO0lBQ0gsQ0FBQztJQUNELGlDQUFLLEdBQUw7UUFBQSxpQkFNQztRQUxDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDOUIsU0FBUyxDQUNSLGNBQU0sT0FBQSxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQS9CLENBQStCLEVBQ3JDLFVBQUMsS0FBSyxJQUFLLE9BQUEsS0FBSyxDQUFDLCtDQUErQyxDQUFDLEVBQXRELENBQXNELENBQ2xFLENBQUM7SUFDTixDQUFDO0lBQ0Qsa0NBQU0sR0FBTjtRQUFBLGlCQVNDO1FBUkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUNqQyxTQUFTLENBQ1I7WUFDRSxLQUFLLENBQUMsd0NBQXdDLENBQUMsQ0FBQztZQUNoRCxLQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdkIsQ0FBQyxFQUNELGNBQU0sT0FBQSxLQUFLLENBQUMsc0RBQXNELENBQUMsRUFBN0QsQ0FBNkQsQ0FDcEUsQ0FBQztJQUNOLENBQUM7SUFDRCx5Q0FBYSxHQUFiO1FBQ0UsTUFBTSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDNUIsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUNsQixJQUFJLENBQUMsVUFBQyxVQUFVO1lBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1lBQ2pELElBQUksS0FBSyxHQUFHLElBQUksYUFBSyxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsR0FBRztZQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRCxzQ0FBVSxHQUFWO1FBQ0UsSUFBSSxlQUFlLEdBQUcsSUFBSSwrQ0FBZSxFQUFFLENBQUM7UUFDNUMsOEJBQThCO1FBQzlCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQztRQUNoQixlQUFlLENBQUMsU0FBUyxFQUFFO2FBQzFCLElBQUksQ0FDSCxVQUFDLEtBQWM7WUFDYixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFjLEtBQU8sQ0FBQyxDQUFDO1FBQ3JDLENBQUMsQ0FDRixDQUFDO1FBQ0YsZUFBZSxDQUFDLGlCQUFpQixDQUFDO1lBQ2hDLEtBQUssRUFBRSx5QkFBeUI7WUFDaEMsT0FBTyxFQUFFLGlCQUFpQjtTQUMzQixDQUFDLENBQUMsSUFBSSxDQUNIO1lBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDLEVBQ0Q7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUNKLENBQUE7SUFDSCxDQUFDO0lBQ0QsMENBQWMsR0FBZDtRQUNFLElBQUksY0FBYyxHQUFHLElBQUksNENBQWMsRUFBRSxDQUFDO1FBQzFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7WUFDbEIsT0FBTyxFQUFFLGlCQUFpQjtZQUMxQixvQkFBb0IsRUFBRSxJQUFJO1lBQzFCLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLGFBQWEsRUFBRSxjQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQSxDQUFBLENBQUM7WUFDckQscUJBQXFCLEVBQUUsR0FBRztZQUMxQixXQUFXLEVBQUUsVUFBVTtZQUN2QiwyQ0FBMkMsRUFBRSxJQUFJO1NBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxNQUFNO1lBQ2IsK0ZBQStGO1lBQy9GLEtBQUssQ0FBQztnQkFDSixLQUFLLEVBQUUsYUFBYTtnQkFDcEIsT0FBTyxFQUFFLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSTtnQkFDaEUsWUFBWSxFQUFFLElBQUk7YUFDbkIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUFFLFVBQUMsWUFBWTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FDRixDQUFDO0lBQ0YsQ0FBQztJQUNILHdCQUFDO0FBQUQsQ0FBQyxBQTdIRCxJQTZIQztBQS9GeUI7SUFBdkIsZ0JBQVMsQ0FBQyxXQUFXLENBQUM7OEJBQVksaUJBQVU7b0RBQUM7QUE5Qm5DLGlCQUFpQjtJQU43QixnQkFBUyxDQUFDO1FBQ1QsUUFBUSxFQUFFLFFBQVE7UUFDbEIsU0FBUyxFQUFFLENBQUMsMEJBQVcsQ0FBQztRQUN4QixXQUFXLEVBQUUsZ0NBQWdDO1FBQzdDLFNBQVMsRUFBRSxDQUFDLHNDQUFzQyxFQUFFLCtCQUErQixDQUFDO0tBQ3JGLENBQUM7cUNBaUMyQix1QkFBYyxFQUFrQixlQUFNLEVBQXVCLDBCQUFXLEVBQWdCLFdBQUk7R0FoQzVHLGlCQUFpQixDQTZIN0I7QUE3SFksOENBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXJcIjtcclxuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlci5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xyXG5pbXBvcnQgeyBDb2xvciB9IGZyb20gXCJjb2xvclwiO1xyXG5pbXBvcnQgeyBWaWV3IH0gZnJvbSBcInVpL2NvcmUvdmlld1wiO1xyXG5pbXBvcnQgKiBhcyBjYW1lcmEgZnJvbSBcIm5hdGl2ZXNjcmlwdC1jYW1lcmFcIjtcclxuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwidWkvaW1hZ2VcIjtcclxuaW1wb3J0IHsgQmFyY29kZVNjYW5uZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWJhcmNvZGVzY2FubmVyXCI7XHJcbmltcG9ydCB7IEZpbmdlcnByaW50QXV0aCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZmluZ2VycHJpbnQtYXV0aFwiO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiBcIm15LWFwcFwiLFxyXG4gIHByb3ZpZGVyczogW1VzZXJTZXJ2aWNlXSxcclxuICB0ZW1wbGF0ZVVybDogXCIuL3BhZ2VzL21lcmNoYW50L21lcmNoYW50Lmh0bWxcIixcclxuICBzdHlsZVVybHM6IFtcIi4vcGFnZXMvbWVyY2hhbnQvbWVyY2hhbnQtY29tbW9uLmNzc1wiLCBcIi4vcGFnZXMvbWVyY2hhbnQvbWVyY2hhbnQuY3NzXCJdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBNZXJjaGFudENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgbWVybmFtZTogc3RyaW5nO1xyXG4gIHByaXZhdGUgc3ViOiBhbnk7XHJcbiAgcHVibGljIGRpc3BsYXlxciA9IGZhbHNlO1xyXG5cclxuICBwYXltZW50KCkge1xyXG4gICAgXHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJ2NvbmZpcm0nLCB7YW1vdW50OnRoaXMudXNlci5hbW91bnQsdHlwZTonbWVyY2hhbnQnfV0pO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlUVIoKXtcclxuICAgIHRoaXMuZGlzcGxheXFyID0gIXRoaXMuZGlzcGxheXFyO1xyXG4gIH1cclxuXHJcbiAgb25UYXAoKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkZpcnN0Q29tcG9uZW50LlRhcHBlZCFcIik7XHJcbn1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICAvL3RoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xyXG4gICAgICAgIC8vdGhpcy5wYWdlLmJhY2tncm91bmRJbWFnZSA9IFwicmVzOi8vYmdcIjtcclxuICAgICAgdGhpcy5zdWIgPSB0aGlzLnJvdXRlLnBhcmFtcy5zdWJzY3JpYmUocGFyYW1zID0+IHtcclxuICAgICAgICB0aGlzLm1lcm5hbWUgPSBwYXJhbXNbJ2lkJ107IC8vICgrKSBjb252ZXJ0cyBzdHJpbmcgJ2lkJyB0byBhIG51bWJlclxyXG5cclxuICAgICAgLy8gSW4gYSByZWFsIGFwcDogZGlzcGF0Y2ggYWN0aW9uIHRvIGxvYWQgdGhlIGRldGFpbHMgaGVyZS5cclxuICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgdXNlcjogVXNlcjtcclxuICBpc0xvZ2dpbmdJbiA9IHRydWU7XHJcbiAgQFZpZXdDaGlsZChcImNvbnRhaW5lclwiKSBjb250YWluZXI6IEVsZW1lbnRSZWY7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIHVzZXJTZXJ2aWNlOiBVc2VyU2VydmljZSwgcHJpdmF0ZSBwYWdlOiBQYWdlKSB7XHJcbiAgICB0aGlzLnVzZXIgPSBuZXcgVXNlcigpO1xyXG4gICAgdGhpcy51c2VyLmVtYWlsID0gXCJ0ZXN0Y3VzdG9tZXJAbWFzdGVyY2FyZC5jb21cIjtcclxuICAgIHRoaXMudXNlci5wYXNzd29yZCA9IFwicGFzc3dvcmRcIjtcclxuICAgIHRoaXMudXNlci5jaXR5ID0gXCJQdW5lXCI7XHJcbiAgICB0aGlzLnVzZXIubG9jYWxpdHkgPSBcIlllcndhZGFcIjtcclxuICAgIHRoaXMudXNlci5maXJzdG5hbWUgPSBcIlNhY2hpblwiO1xyXG4gICAgdGhpcy51c2VyLmxhc3RuYW1lID0gXCJBZ3Jhd2FsbGFcIjtcclxuICAgIHRoaXMudXNlci5hZGRyZXNzID0gXCJNYXN0ZXJjYXJkIDh0aCBmbG9vciwgWWVyd2FkYVwiO1xyXG4gICAgdGhpcy51c2VyLnBvc3RhbGNvZGUgPSBcIjQxMTAwMVwiO1xyXG4gICAgdGhpcy51c2VyLm1vYmlsZSA9IFwiNzcxMTIyMzM0NFwiO1xyXG4gICAgdGhpcy51c2VyLmZpcm1uYW1lID0gXCJHcm9jZXJ5IFN0b3JlXCI7XHJcbiAgfVxyXG4gIHN1Ym1pdCgpIHtcclxuICAgIGlmICh0aGlzLmlzTG9nZ2luZ0luKSB7XHJcbiAgICAgIHRoaXMubG9naW4oKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuc2lnblVwKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGxvZ2luKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5sb2dpbih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4gdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL2xpc3RcIl0pLFxyXG4gICAgICAgIChlcnJvcikgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIGNvdWxkIG5vdCBmaW5kIHlvdXIgYWNjb3VudC5cIilcclxuICAgICAgKTtcclxuICB9XHJcbiAgc2lnblVwKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5yZWdpc3Rlcih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgYWxlcnQoXCJZb3VyIGFjY291bnQgd2FzIHN1Y2Nlc3NmdWxseSBjcmVhdGVkLlwiKTtcclxuICAgICAgICAgIHRoaXMudG9nZ2xlRGlzcGxheSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgKCkgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIHdlcmUgdW5hYmxlIHRvIGNyZWF0ZSB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHRvZ2dsZURpc3BsYXkoKSB7XHJcbiAgICBjYW1lcmEucmVxdWVzdFBlcm1pc3Npb25zKCk7XHJcbiAgICBjYW1lcmEudGFrZVBpY3R1cmUoKS5cclxuICAgICAgdGhlbigoaW1hZ2VBc3NldCkgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJSZXN1bHQgaXMgYW4gaW1hZ2UgYXNzZXQgaW5zdGFuY2VcIik7XHJcbiAgICAgICAgICB2YXIgaW1hZ2UgPSBuZXcgSW1hZ2UoKTtcclxuICAgICAgICAgIGltYWdlLnNyYyA9IGltYWdlQXNzZXQ7XHJcbiAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgLT4gXCIgKyBlcnIubWVzc2FnZSk7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuICBzY2FuRmluZ2VyKCl7XHJcbiAgICBsZXQgZmluZ2VycHJpbnRBdXRoID0gbmV3IEZpbmdlcnByaW50QXV0aCgpO1xyXG4gICAgLy90aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvXCJdKTtcclxuICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgIGZpbmdlcnByaW50QXV0aC5hdmFpbGFibGUoKVxyXG4gICAgLnRoZW4oXHJcbiAgICAgIChhdmFpbDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBBdmFpbGFibGU/ICR7YXZhaWx9YCk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgICBmaW5nZXJwcmludEF1dGgudmVyaWZ5RmluZ2VycHJpbnQoe1xyXG4gICAgICB0aXRsZTogJ1NjYW4gZmluZ2VyIHRvIGNvbnRpbnVlJywgLy8gb3B0aW9uYWwgdGl0bGUgKHVzZWQgb25seSBvbiBBbmRyb2lkKVxyXG4gICAgICBtZXNzYWdlOiAnU2NhbiB5ZXIgZmluZ2VyJ1xyXG4gICAgfSkudGhlbihcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgd2FzIE9LXCIpO1xyXG4gICAgICAgICAgc2VsZi5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgTk9UIE9LXCIpO1xyXG4gICAgICAgIH1cclxuICAgIClcclxuICB9XHJcbiAgdG9nZ2xlRGlzcGxheTEoKSB7XHJcbiAgICBsZXQgYmFyY29kZXNjYW5uZXIgPSBuZXcgQmFyY29kZVNjYW5uZXIoKTtcclxuICAgIGJhcmNvZGVzY2FubmVyLnNjYW4oe1xyXG4gICAgICBmb3JtYXRzOiBcIlFSX0NPREUsIEVBTl8xM1wiLFxyXG4gICAgICBzaG93RmxpcENhbWVyYUJ1dHRvbjogdHJ1ZSxcclxuICAgICAgYmVlcE9uU2NhbjogdHJ1ZSwgXHJcbiAgICAgIGNsb3NlQ2FsbGJhY2s6ICgpID0+IHsgY29uc29sZS5sb2coXCJTY2FubmVyIGNsb3NlZFwiKX0sIFxyXG4gICAgICByZXN1bHREaXNwbGF5RHVyYXRpb246IDUwMCxcclxuICAgICAgb3JpZW50YXRpb246IFwicG9ydHJhaXRcIixcclxuICAgICAgb3BlblNldHRpbmdzSWZQZXJtaXNzaW9uV2FzUHJldmlvdXNseURlbmllZDogdHJ1ZVxyXG4gICAgfSkudGhlbigocmVzdWx0KSA9PiB7ICAgICAgXHJcbiAgICAgIC8vIE5vdGUgdGhhdCB0aGlzIFByb21pc2UgaXMgbmV2ZXIgaW52b2tlZCB3aGVuIGEgJ2NvbnRpbnVvdXNTY2FuQ2FsbGJhY2snIGZ1bmN0aW9uIGlzIHByb3ZpZGVkXHJcbiAgICAgIGFsZXJ0KHtcclxuICAgICAgICB0aXRsZTogXCJTY2FuIHJlc3VsdFwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRm9ybWF0OiBcIiArIHJlc3VsdC5mb3JtYXQgKyBcIixcXG5WYWx1ZTogXCIgKyByZXN1bHQudGV4dCxcclxuICAgICAgICBva0J1dHRvblRleHQ6IFwiT0tcIlxyXG4gICAgICB9KTtcclxuICAgIH0sIChlcnJvck1lc3NhZ2UpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJObyBzY2FuLiBcIiArIGVycm9yTWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgKTtcclxuICB9XHJcbn0iXX0=