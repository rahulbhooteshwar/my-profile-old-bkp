import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";

import { User } from "../../shared/user/user";
import { UserService } from "../../shared/user/user.service";
import { ActivatedRoute, Router } from "@angular/router";
import { Page } from "ui/page";
import { Color } from "color";
import { View } from "ui/core/view";
import * as camera from "nativescript-camera";
import { Image } from "ui/image";
import { BarcodeScanner } from "nativescript-barcodescanner";
import { FingerprintAuth } from "nativescript-fingerprint-auth";


@Component({
  selector: "my-app",
  providers: [UserService],
  templateUrl: "./pages/merchant/merchant.html",
  styleUrls: ["./pages/merchant/merchant-common.css", "./pages/merchant/merchant.css"]
})
export class MerchantComponent implements OnInit {
  mername: string;
  private sub: any;
  public displayqr = false;

  payment() {
    
    this.router.navigate(['confirm', {amount:this.user.amount,type:'merchant'}]);
  }

  toggleQR(){
    this.displayqr = !this.displayqr;
  }

  onTap() {
    console.log("FirstComponent.Tapped!");
}

    ngOnInit() {
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
      this.sub = this.route.params.subscribe(params => {
        this.mername = params['id']; // (+) converts string 'id' to a number

      // In a real app: dispatch action to load the details here.
   });
      }

  user: User;
  isLoggingIn = true;
  @ViewChild("container") container: ElementRef;

  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService, private page: Page) {
    this.user = new User();
    this.user.email = "testcustomer@mastercard.com";
    this.user.password = "password";
    this.user.city = "Pune";
    this.user.locality = "Yerwada";
    this.user.firstname = "Sachin";
    this.user.lastname = "Agrawalla";
    this.user.address = "Mastercard 8th floor, Yerwada";
    this.user.postalcode = "411001";
    this.user.mobile = "7711223344";
    this.user.firmname = "Grocery Store";
  }
  submit() {
    if (this.isLoggingIn) {
      this.login();
    } else {
      this.signUp();
    }
  }
  login() {
    this.userService.login(this.user)
      .subscribe(
        () => this.router.navigate(["/list"]),
        (error) => alert("Unfortunately we could not find your account.")
      );
  }
  signUp() {
    this.userService.register(this.user)
      .subscribe(
        () => {
          alert("Your account was successfully created.");
          this.toggleDisplay();
        },
        () => alert("Unfortunately we were unable to create your account.")
      );
  }
  toggleDisplay() {
    camera.requestPermissions();
    camera.takePicture().
      then((imageAsset) => {
          console.log("Result is an image asset instance");
          var image = new Image();
          image.src = imageAsset;
      }).catch((err) => {
          console.log("Error -> " + err.message);
      });
  }
  scanFinger(){
    let fingerprintAuth = new FingerprintAuth();
    //this.router.navigate(["/"]);
    let self = this;
    fingerprintAuth.available()
    .then(
      (avail: boolean) => {
        console.log(`Available? ${avail}`);
      }
    );
    fingerprintAuth.verifyFingerprint({
      title: 'Scan finger to continue', // optional title (used only on Android)
      message: 'Scan yer finger'
    }).then(
        function() {
          console.log("Fingerprint was OK");
          self.router.navigate(["/"]);
        },
        function() {
          console.log("Fingerprint NOT OK");
        }
    )
  }
  toggleDisplay1() {
    let barcodescanner = new BarcodeScanner();
    barcodescanner.scan({
      formats: "QR_CODE, EAN_13",
      showFlipCameraButton: true,
      beepOnScan: true, 
      closeCallback: () => { console.log("Scanner closed")}, 
      resultDisplayDuration: 500,
      orientation: "portrait",
      openSettingsIfPermissionWasPreviouslyDenied: true
    }).then((result) => {      
      // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
      alert({
        title: "Scan result",
        message: "Format: " + result.format + ",\nValue: " + result.text,
        okButtonText: "OK"
      });
    }, (errorMessage) => {
      console.log("No scan. " + errorMessage);
    }
  );
  }
}