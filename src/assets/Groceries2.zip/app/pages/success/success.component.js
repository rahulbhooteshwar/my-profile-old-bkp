"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var SuccessComponent = (function () {
    function SuccessComponent(route, router, userService, page) {
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.displayqr = false;
        this.isLoading = true;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
        this.user.firmname = "Grocery Store";
        this.aadhaar = '2342';
        this.fullname = this.user.firstname + " " + this.user.lastname;
    }
    SuccessComponent.prototype.toggleQR = function () {
        this.displayqr = !this.displayqr;
    };
    SuccessComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    SuccessComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.isLoading = false;
        }, 4000);
        this.route.params.forEach(function (urlParams) {
            _this.amount = urlParams['amount'];
            if (urlParams['type'] == 'merchant') {
                _this.type = 'received';
            }
            else {
                _this.type = 'paid';
            }
        });
    };
    SuccessComponent.prototype.home = function () {
        if (this.type == 'received') {
            this.router.navigate(["/mer1/Grocery Store"]);
        }
        else {
            this.router.navigate(["/cus1"]);
        }
    };
    SuccessComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    SuccessComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    SuccessComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    SuccessComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    SuccessComponent.prototype.scanpay = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan your finger to pay'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/success", { amount: self.amount, type: self.type }]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    SuccessComponent.prototype.toggleDisplay1 = function () {
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 500,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            alert({
                title: "Scan result",
                message: "Format: " + result.format + ",\nValue: " + result.text,
                okButtonText: "OK"
            });
        }, function (errorMessage) {
            console.log("No scan. " + errorMessage);
        });
    };
    return SuccessComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], SuccessComponent.prototype, "container", void 0);
SuccessComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/success/success.html",
        styleUrls: ["./pages/success/success-common.css", "./pages/success/success.css"]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService, page_1.Page])
], SuccessComponent);
exports.SuccessComponent = SuccessComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3VjY2Vzcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzdWNjZXNzLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5RTtBQUV6RSwrQ0FBOEM7QUFDOUMsK0RBQTZEO0FBQzdELDBDQUF5RDtBQUN6RCxnQ0FBK0I7QUFHL0IsNENBQThDO0FBQzlDLGtDQUFpQztBQUNqQywyRUFBNkQ7QUFDN0QsK0VBQWdFO0FBU2hFLElBQWEsZ0JBQWdCO0lBOEMzQiwwQkFBb0IsS0FBcUIsRUFBVSxNQUFjLEVBQVUsV0FBd0IsRUFBVSxJQUFVO1FBQW5HLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQVUsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQVUsU0FBSSxHQUFKLElBQUksQ0FBTTtRQXhDaEgsY0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixjQUFTLEdBQUcsSUFBSSxDQUFDO1FBb0NqQixnQkFBVyxHQUFHLElBQUksQ0FBQztRQUlqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksV0FBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsNkJBQTZCLENBQUM7UUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7UUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztRQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRywrQkFBK0IsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7UUFDaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztRQUNyQyxJQUFJLENBQUMsT0FBTyxHQUFDLE1BQU0sQ0FBQztRQUNwQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUNqRSxDQUFDO0lBbkRELG1DQUFRLEdBQVI7UUFDRSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNuQyxDQUFDO0lBRUQsZ0NBQUssR0FBTDtRQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRUcsbUNBQVEsR0FBUjtRQUFBLGlCQWNDO1FBYkMsVUFBVSxDQUFDO1lBQ1QsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUE7UUFDeEIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRVQsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUMsU0FBUztZQUNsQyxLQUFJLENBQUMsTUFBTSxHQUFFLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNqQyxFQUFFLENBQUEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDbkMsS0FBSSxDQUFDLElBQUksR0FBQyxVQUFVLENBQUM7WUFDdkIsQ0FBQztZQUFBLElBQUksQ0FBQyxDQUFDO2dCQUNMLEtBQUksQ0FBQyxJQUFJLEdBQUMsTUFBTSxDQUFDO1lBQ25CLENBQUM7UUFFSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTCwrQkFBSSxHQUFKO1FBQ0UsRUFBRSxDQUFBLENBQUMsSUFBSSxDQUFDLElBQUksSUFBRSxVQUFVLENBQUMsQ0FBQSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO1FBQ2hELENBQUM7UUFBQSxJQUFJLENBQUMsQ0FBQztZQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNsQyxDQUFDO0lBRUgsQ0FBQztJQXFCQyxpQ0FBTSxHQUFOO1FBQ0UsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztRQUFDLElBQUksQ0FBQyxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2hCLENBQUM7SUFDSCxDQUFDO0lBQ0QsZ0NBQUssR0FBTDtRQUFBLGlCQU1DO1FBTEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUM5QixTQUFTLENBQ1IsY0FBTSxPQUFBLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBL0IsQ0FBK0IsRUFDckMsVUFBQyxLQUFLLElBQUssT0FBQSxLQUFLLENBQUMsK0NBQStDLENBQUMsRUFBdEQsQ0FBc0QsQ0FDbEUsQ0FBQztJQUNOLENBQUM7SUFDRCxpQ0FBTSxHQUFOO1FBQUEsaUJBU0M7UUFSQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQ2pDLFNBQVMsQ0FDUjtZQUNFLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ2hELEtBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN2QixDQUFDLEVBQ0QsY0FBTSxPQUFBLEtBQUssQ0FBQyxzREFBc0QsQ0FBQyxFQUE3RCxDQUE2RCxDQUNwRSxDQUFDO0lBQ04sQ0FBQztJQUNELHdDQUFhLEdBQWI7UUFDRSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxVQUFDLFVBQVU7WUFDWixPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7WUFDakQsSUFBSSxLQUFLLEdBQUcsSUFBSSxhQUFLLEVBQUUsQ0FBQztZQUN4QixLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxHQUFHO1lBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELGtDQUFPLEdBQVA7UUFDRSxJQUFJLGVBQWUsR0FBRyxJQUFJLCtDQUFlLEVBQUUsQ0FBQztRQUM1Qyw4QkFBOEI7UUFDOUIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2hCLGVBQWUsQ0FBQyxTQUFTLEVBQUU7YUFDMUIsSUFBSSxDQUNILFVBQUMsS0FBYztZQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWMsS0FBTyxDQUFDLENBQUM7UUFDckMsQ0FBQyxDQUNGLENBQUM7UUFDRixlQUFlLENBQUMsaUJBQWlCLENBQUM7WUFDaEMsS0FBSyxFQUFFLHlCQUF5QjtZQUNoQyxPQUFPLEVBQUUseUJBQXlCO1NBQ25DLENBQUMsQ0FBQyxJQUFJLENBQ0g7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQztRQUMzRSxDQUFDLEVBQ0Q7WUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUNKLENBQUE7SUFDSCxDQUFDO0lBQ0QseUNBQWMsR0FBZDtRQUNFLElBQUksY0FBYyxHQUFHLElBQUksNENBQWMsRUFBRSxDQUFDO1FBQzFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7WUFDbEIsT0FBTyxFQUFFLGlCQUFpQjtZQUMxQixvQkFBb0IsRUFBRSxJQUFJO1lBQzFCLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLGFBQWEsRUFBRSxjQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQSxDQUFBLENBQUM7WUFDckQscUJBQXFCLEVBQUUsR0FBRztZQUMxQixXQUFXLEVBQUUsVUFBVTtZQUN2QiwyQ0FBMkMsRUFBRSxJQUFJO1NBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxNQUFNO1lBQ2IsK0ZBQStGO1lBQy9GLEtBQUssQ0FBQztnQkFDSixLQUFLLEVBQUUsYUFBYTtnQkFDcEIsT0FBTyxFQUFFLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSTtnQkFDaEUsWUFBWSxFQUFFLElBQUk7YUFDbkIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUFFLFVBQUMsWUFBWTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FDRixDQUFDO0lBQ0YsQ0FBQztJQUNILHVCQUFDO0FBQUQsQ0FBQyxBQTdJRCxJQTZJQztBQWpHeUI7SUFBdkIsZ0JBQVMsQ0FBQyxXQUFXLENBQUM7OEJBQVksaUJBQVU7bURBQUM7QUE1Q25DLGdCQUFnQjtJQU41QixnQkFBUyxDQUFDO1FBQ1QsUUFBUSxFQUFFLFFBQVE7UUFDbEIsU0FBUyxFQUFFLENBQUMsMEJBQVcsQ0FBQztRQUN4QixXQUFXLEVBQUUsOEJBQThCO1FBQzNDLFNBQVMsRUFBRSxDQUFDLG9DQUFvQyxFQUFFLDZCQUE2QixDQUFDO0tBQ2pGLENBQUM7cUNBK0MyQix1QkFBYyxFQUFrQixlQUFNLEVBQXVCLDBCQUFXLEVBQWdCLFdBQUk7R0E5QzVHLGdCQUFnQixDQTZJNUI7QUE3SVksNENBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBPbkluaXQsIFZpZXdDaGlsZCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcblxyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91c2VyL3VzZXJcIjtcclxuaW1wb3J0IHsgVXNlclNlcnZpY2UgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlci5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlLCBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IFBhZ2UgfSBmcm9tIFwidWkvcGFnZVwiO1xyXG5pbXBvcnQgeyBDb2xvciB9IGZyb20gXCJjb2xvclwiO1xyXG5pbXBvcnQgeyBWaWV3IH0gZnJvbSBcInVpL2NvcmUvdmlld1wiO1xyXG5pbXBvcnQgKiBhcyBjYW1lcmEgZnJvbSBcIm5hdGl2ZXNjcmlwdC1jYW1lcmFcIjtcclxuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwidWkvaW1hZ2VcIjtcclxuaW1wb3J0IHsgQmFyY29kZVNjYW5uZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWJhcmNvZGVzY2FubmVyXCI7XHJcbmltcG9ydCB7IEZpbmdlcnByaW50QXV0aCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZmluZ2VycHJpbnQtYXV0aFwiO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiBcIm15LWFwcFwiLFxyXG4gIHByb3ZpZGVyczogW1VzZXJTZXJ2aWNlXSxcclxuICB0ZW1wbGF0ZVVybDogXCIuL3BhZ2VzL3N1Y2Nlc3Mvc3VjY2Vzcy5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXCIuL3BhZ2VzL3N1Y2Nlc3Mvc3VjY2Vzcy1jb21tb24uY3NzXCIsIFwiLi9wYWdlcy9zdWNjZXNzL3N1Y2Nlc3MuY3NzXCJdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBTdWNjZXNzQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBmdWxsbmFtZTogc3RyaW5nO1xyXG4gIGFtb3VudDogc3RyaW5nO1xyXG4gIGFhZGhhYXI6IHN0cmluZztcclxuICB0eXBlOiBzdHJpbmc7XHJcbiAgcHJpdmF0ZSBzdWI6IGFueTtcclxuICBwdWJsaWMgZGlzcGxheXFyID0gZmFsc2U7XHJcbiAgaXNMb2FkaW5nID0gdHJ1ZTtcclxuXHJcbiAgdG9nZ2xlUVIoKXtcclxuICAgIHRoaXMuZGlzcGxheXFyID0gIXRoaXMuZGlzcGxheXFyO1xyXG4gIH1cclxuXHJcbiAgb25UYXAoKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkZpcnN0Q29tcG9uZW50LlRhcHBlZCFcIik7XHJcbn1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgc2V0VGltZW91dCgoKT0+e1xyXG4gICAgICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2VcclxuICAgICAgfSwgNDAwMCk7XHJcbiAgICAgIFxyXG4gICAgICB0aGlzLnJvdXRlLnBhcmFtcy5mb3JFYWNoKCh1cmxQYXJhbXMpID0+IHtcclxuICAgICAgICB0aGlzLmFtb3VudD0gdXJsUGFyYW1zWydhbW91bnQnXTtcclxuICAgICAgICBpZih1cmxQYXJhbXNbJ3R5cGUnXSA9PSAnbWVyY2hhbnQnKSB7ICAgICAgICAgIFxyXG4gICAgICAgICAgdGhpcy50eXBlPSdyZWNlaXZlZCc7XHJcbiAgICAgICAgfWVsc2UgeyAgICAgICAgICBcclxuICAgICAgICAgIHRoaXMudHlwZT0ncGFpZCc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG5ob21lKCkge1xyXG4gIGlmKHRoaXMudHlwZT09J3JlY2VpdmVkJyl7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvbWVyMS9Hcm9jZXJ5IFN0b3JlXCJdKTtcclxuICB9ZWxzZSB7XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvY3VzMVwiXSk7XHJcbiAgfVxyXG4gIFxyXG59XHJcblxyXG4gIHVzZXI6IFVzZXI7XHJcbiAgaXNMb2dnaW5nSW4gPSB0cnVlO1xyXG4gIEBWaWV3Q2hpbGQoXCJjb250YWluZXJcIikgY29udGFpbmVyOiBFbGVtZW50UmVmO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSwgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSB1c2VyU2VydmljZTogVXNlclNlcnZpY2UsIHByaXZhdGUgcGFnZTogUGFnZSkge1xyXG4gICAgdGhpcy51c2VyID0gbmV3IFVzZXIoKTtcclxuICAgIHRoaXMudXNlci5lbWFpbCA9IFwidGVzdGN1c3RvbWVyQG1hc3RlcmNhcmQuY29tXCI7XHJcbiAgICB0aGlzLnVzZXIucGFzc3dvcmQgPSBcInBhc3N3b3JkXCI7XHJcbiAgICB0aGlzLnVzZXIuY2l0eSA9IFwiUHVuZVwiO1xyXG4gICAgdGhpcy51c2VyLmxvY2FsaXR5ID0gXCJZZXJ3YWRhXCI7XHJcbiAgICB0aGlzLnVzZXIuZmlyc3RuYW1lID0gXCJTYWNoaW5cIjtcclxuICAgIHRoaXMudXNlci5sYXN0bmFtZSA9IFwiQWdyYXdhbGxhXCI7XHJcbiAgICB0aGlzLnVzZXIuYWRkcmVzcyA9IFwiTWFzdGVyY2FyZCA4dGggZmxvb3IsIFllcndhZGFcIjtcclxuICAgIHRoaXMudXNlci5wb3N0YWxjb2RlID0gXCI0MTEwMDFcIjtcclxuICAgIHRoaXMudXNlci5tb2JpbGUgPSBcIjc3MTEyMjMzNDRcIjtcclxuICAgIHRoaXMudXNlci5maXJtbmFtZSA9IFwiR3JvY2VyeSBTdG9yZVwiO1xyXG4gICAgdGhpcy5hYWRoYWFyPScyMzQyJztcclxuICAgIHRoaXMuZnVsbG5hbWUgPSB0aGlzLnVzZXIuZmlyc3RuYW1lICsgXCIgXCIgKyB0aGlzLnVzZXIubGFzdG5hbWU7XHJcbiAgfVxyXG4gIHN1Ym1pdCgpIHtcclxuICAgIGlmICh0aGlzLmlzTG9nZ2luZ0luKSB7XHJcbiAgICAgIHRoaXMubG9naW4oKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuc2lnblVwKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGxvZ2luKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5sb2dpbih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4gdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL2xpc3RcIl0pLFxyXG4gICAgICAgIChlcnJvcikgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIGNvdWxkIG5vdCBmaW5kIHlvdXIgYWNjb3VudC5cIilcclxuICAgICAgKTtcclxuICB9XHJcbiAgc2lnblVwKCkge1xyXG4gICAgdGhpcy51c2VyU2VydmljZS5yZWdpc3Rlcih0aGlzLnVzZXIpXHJcbiAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgYWxlcnQoXCJZb3VyIGFjY291bnQgd2FzIHN1Y2Nlc3NmdWxseSBjcmVhdGVkLlwiKTtcclxuICAgICAgICAgIHRoaXMudG9nZ2xlRGlzcGxheSgpO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgKCkgPT4gYWxlcnQoXCJVbmZvcnR1bmF0ZWx5IHdlIHdlcmUgdW5hYmxlIHRvIGNyZWF0ZSB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHRvZ2dsZURpc3BsYXkoKSB7XHJcbiAgICBjYW1lcmEucmVxdWVzdFBlcm1pc3Npb25zKCk7XHJcbiAgICBjYW1lcmEudGFrZVBpY3R1cmUoKS5cclxuICAgICAgdGhlbigoaW1hZ2VBc3NldCkgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJSZXN1bHQgaXMgYW4gaW1hZ2UgYXNzZXQgaW5zdGFuY2VcIik7XHJcbiAgICAgICAgICB2YXIgaW1hZ2UgPSBuZXcgSW1hZ2UoKTtcclxuICAgICAgICAgIGltYWdlLnNyYyA9IGltYWdlQXNzZXQ7XHJcbiAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgLT4gXCIgKyBlcnIubWVzc2FnZSk7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuICBzY2FucGF5KCl7XHJcbiAgICBsZXQgZmluZ2VycHJpbnRBdXRoID0gbmV3IEZpbmdlcnByaW50QXV0aCgpO1xyXG4gICAgLy90aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCIvXCJdKTtcclxuICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgIGZpbmdlcnByaW50QXV0aC5hdmFpbGFibGUoKVxyXG4gICAgLnRoZW4oXHJcbiAgICAgIChhdmFpbDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBBdmFpbGFibGU/ICR7YXZhaWx9YCk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcbiAgICBmaW5nZXJwcmludEF1dGgudmVyaWZ5RmluZ2VycHJpbnQoe1xyXG4gICAgICB0aXRsZTogJ1NjYW4gZmluZ2VyIHRvIGNvbnRpbnVlJywgLy8gb3B0aW9uYWwgdGl0bGUgKHVzZWQgb25seSBvbiBBbmRyb2lkKVxyXG4gICAgICBtZXNzYWdlOiAnU2NhbiB5b3VyIGZpbmdlciB0byBwYXknXHJcbiAgICB9KS50aGVuKFxyXG4gICAgICAgIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJGaW5nZXJwcmludCB3YXMgT0tcIik7XHJcbiAgICAgICAgICBzZWxmLnJvdXRlci5uYXZpZ2F0ZShbXCIvc3VjY2Vzc1wiLCB7YW1vdW50OnNlbGYuYW1vdW50LCB0eXBlOnNlbGYudHlwZX1dKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJGaW5nZXJwcmludCBOT1QgT0tcIik7XHJcbiAgICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuICB0b2dnbGVEaXNwbGF5MSgpIHtcclxuICAgIGxldCBiYXJjb2Rlc2Nhbm5lciA9IG5ldyBCYXJjb2RlU2Nhbm5lcigpO1xyXG4gICAgYmFyY29kZXNjYW5uZXIuc2Nhbih7XHJcbiAgICAgIGZvcm1hdHM6IFwiUVJfQ09ERSwgRUFOXzEzXCIsXHJcbiAgICAgIHNob3dGbGlwQ2FtZXJhQnV0dG9uOiB0cnVlLFxyXG4gICAgICBiZWVwT25TY2FuOiB0cnVlLCBcclxuICAgICAgY2xvc2VDYWxsYmFjazogKCkgPT4geyBjb25zb2xlLmxvZyhcIlNjYW5uZXIgY2xvc2VkXCIpfSwgXHJcbiAgICAgIHJlc3VsdERpc3BsYXlEdXJhdGlvbjogNTAwLFxyXG4gICAgICBvcmllbnRhdGlvbjogXCJwb3J0cmFpdFwiLFxyXG4gICAgICBvcGVuU2V0dGluZ3NJZlBlcm1pc3Npb25XYXNQcmV2aW91c2x5RGVuaWVkOiB0cnVlXHJcbiAgICB9KS50aGVuKChyZXN1bHQpID0+IHsgICAgICBcclxuICAgICAgLy8gTm90ZSB0aGF0IHRoaXMgUHJvbWlzZSBpcyBuZXZlciBpbnZva2VkIHdoZW4gYSAnY29udGludW91c1NjYW5DYWxsYmFjaycgZnVuY3Rpb24gaXMgcHJvdmlkZWRcclxuICAgICAgYWxlcnQoe1xyXG4gICAgICAgIHRpdGxlOiBcIlNjYW4gcmVzdWx0XCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGb3JtYXQ6IFwiICsgcmVzdWx0LmZvcm1hdCArIFwiLFxcblZhbHVlOiBcIiArIHJlc3VsdC50ZXh0LFxyXG4gICAgICAgIG9rQnV0dG9uVGV4dDogXCJPS1wiXHJcbiAgICAgIH0pO1xyXG4gICAgfSwgKGVycm9yTWVzc2FnZSkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIk5vIHNjYW4uIFwiICsgZXJyb3JNZXNzYWdlKTtcclxuICAgIH1cclxuICApO1xyXG4gIH1cclxufSJdfQ==