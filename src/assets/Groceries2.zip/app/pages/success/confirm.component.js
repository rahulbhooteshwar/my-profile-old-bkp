"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var user_1 = require("../../shared/user/user");
var user_service_1 = require("../../shared/user/user.service");
var router_1 = require("@angular/router");
var page_1 = require("ui/page");
var camera = require("nativescript-camera");
var image_1 = require("ui/image");
var nativescript_barcodescanner_1 = require("nativescript-barcodescanner");
var nativescript_fingerprint_auth_1 = require("nativescript-fingerprint-auth");
var ConfirmComponent = (function () {
    function ConfirmComponent(route, router, userService, page) {
        this.route = route;
        this.router = router;
        this.userService = userService;
        this.page = page;
        this.displayqr = false;
        this.isLoggingIn = true;
        this.user = new user_1.User();
        this.user.email = "testcustomer@mastercard.com";
        this.user.password = "password";
        this.user.city = "Pune";
        this.user.locality = "Yerwada";
        this.user.firstname = "Sachin";
        this.user.lastname = "Agrawalla";
        this.user.address = "Mastercard 8th floor, Yerwada";
        this.user.postalcode = "411001";
        this.user.mobile = "7711223344";
        this.user.firmname = "Grocery Store";
        this.aadhaar = '2342';
        this.fullname = this.user.firstname + " " + this.user.lastname;
    }
    ConfirmComponent.prototype.toggleQR = function () {
        this.displayqr = !this.displayqr;
    };
    ConfirmComponent.prototype.onTap = function () {
        console.log("FirstComponent.Tapped!");
    };
    ConfirmComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (urlParams) {
            _this.amount = urlParams['amount'];
            _this.type = urlParams['type'];
        });
    };
    ConfirmComponent.prototype.submit = function () {
        if (this.isLoggingIn) {
            this.login();
        }
        else {
            this.signUp();
        }
    };
    ConfirmComponent.prototype.login = function () {
        var _this = this;
        this.userService.login(this.user)
            .subscribe(function () { return _this.router.navigate(["/list"]); }, function (error) { return alert("Unfortunately we could not find your account."); });
    };
    ConfirmComponent.prototype.signUp = function () {
        var _this = this;
        this.userService.register(this.user)
            .subscribe(function () {
            alert("Your account was successfully created.");
            _this.toggleDisplay();
        }, function () { return alert("Unfortunately we were unable to create your account."); });
    };
    ConfirmComponent.prototype.toggleDisplay = function () {
        camera.requestPermissions();
        camera.takePicture().
            then(function (imageAsset) {
            console.log("Result is an image asset instance");
            var image = new image_1.Image();
            image.src = imageAsset;
        }).catch(function (err) {
            console.log("Error -> " + err.message);
        });
    };
    ConfirmComponent.prototype.scanpay = function () {
        var fingerprintAuth = new nativescript_fingerprint_auth_1.FingerprintAuth();
        //this.router.navigate(["/"]);
        var self = this;
        fingerprintAuth.available()
            .then(function (avail) {
            console.log("Available? " + avail);
        });
        fingerprintAuth.verifyFingerprint({
            title: 'Scan finger to continue',
            message: 'Scan your finger to pay'
        }).then(function () {
            console.log("Fingerprint was OK");
            self.router.navigate(["/success", { amount: self.amount, type: self.type }]);
        }, function () {
            console.log("Fingerprint NOT OK");
        });
    };
    ConfirmComponent.prototype.toggleDisplay1 = function () {
        var barcodescanner = new nativescript_barcodescanner_1.BarcodeScanner();
        barcodescanner.scan({
            formats: "QR_CODE, EAN_13",
            showFlipCameraButton: true,
            beepOnScan: true,
            closeCallback: function () { console.log("Scanner closed"); },
            resultDisplayDuration: 500,
            orientation: "portrait",
            openSettingsIfPermissionWasPreviouslyDenied: true
        }).then(function (result) {
            // Note that this Promise is never invoked when a 'continuousScanCallback' function is provided
            alert({
                title: "Scan result",
                message: "Format: " + result.format + ",\nValue: " + result.text,
                okButtonText: "OK"
            });
        }, function (errorMessage) {
            console.log("No scan. " + errorMessage);
        });
    };
    return ConfirmComponent;
}());
__decorate([
    core_1.ViewChild("container"),
    __metadata("design:type", core_1.ElementRef)
], ConfirmComponent.prototype, "container", void 0);
ConfirmComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        providers: [user_service_1.UserService],
        templateUrl: "./pages/confirm/confirm.html",
        styleUrls: ["./pages/confirm/confirm-common.css", "./pages/confirm/confirm.css"]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, user_service_1.UserService, page_1.Page])
], ConfirmComponent);
exports.ConfirmComponent = ConfirmComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlybS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25maXJtLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUF5RTtBQUV6RSwrQ0FBOEM7QUFDOUMsK0RBQTZEO0FBQzdELDBDQUF5RDtBQUN6RCxnQ0FBK0I7QUFHL0IsNENBQThDO0FBQzlDLGtDQUFpQztBQUNqQywyRUFBNkQ7QUFDN0QsK0VBQWdFO0FBU2hFLElBQWEsZ0JBQWdCO0lBNkIzQiwwQkFBb0IsS0FBcUIsRUFBVSxNQUFjLEVBQVUsV0FBd0IsRUFBVSxJQUFVO1FBQW5HLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQVUsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQVUsU0FBSSxHQUFKLElBQUksQ0FBTTtRQXZCaEgsY0FBUyxHQUFHLEtBQUssQ0FBQztRQW9CekIsZ0JBQVcsR0FBRyxJQUFJLENBQUM7UUFJakIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLFdBQUksRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLDZCQUE2QixDQUFDO1FBQ2hELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztRQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7UUFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsK0JBQStCLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQztRQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7UUFDckMsSUFBSSxDQUFDLE9BQU8sR0FBQyxNQUFNLENBQUM7UUFDcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDakUsQ0FBQztJQW5DRCxtQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUVELGdDQUFLLEdBQUw7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVHLG1DQUFRLEdBQVI7UUFBQSxpQkFPQztRQUxDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFDLFNBQVM7WUFDbEMsS0FBSSxDQUFDLE1BQU0sR0FBRSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDakMsS0FBSSxDQUFDLElBQUksR0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFOUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBcUJILGlDQUFNLEdBQU47UUFDRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUNyQixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDZixDQUFDO1FBQUMsSUFBSSxDQUFDLENBQUM7WUFDTixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDaEIsQ0FBQztJQUNILENBQUM7SUFDRCxnQ0FBSyxHQUFMO1FBQUEsaUJBTUM7UUFMQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQzlCLFNBQVMsQ0FDUixjQUFNLE9BQUEsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUEvQixDQUErQixFQUNyQyxVQUFDLEtBQUssSUFBSyxPQUFBLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxFQUF0RCxDQUFzRCxDQUNsRSxDQUFDO0lBQ04sQ0FBQztJQUNELGlDQUFNLEdBQU47UUFBQSxpQkFTQztRQVJDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDakMsU0FBUyxDQUNSO1lBQ0UsS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7WUFDaEQsS0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZCLENBQUMsRUFDRCxjQUFNLE9BQUEsS0FBSyxDQUFDLHNEQUFzRCxDQUFDLEVBQTdELENBQTZELENBQ3BFLENBQUM7SUFDTixDQUFDO0lBQ0Qsd0NBQWEsR0FBYjtRQUNFLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzVCLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFVBQUMsVUFBVTtZQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztZQUNqRCxJQUFJLEtBQUssR0FBRyxJQUFJLGFBQUssRUFBRSxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFDLEdBQUc7WUFDVCxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0Qsa0NBQU8sR0FBUDtRQUNFLElBQUksZUFBZSxHQUFHLElBQUksK0NBQWUsRUFBRSxDQUFDO1FBQzVDLDhCQUE4QjtRQUM5QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7UUFDaEIsZUFBZSxDQUFDLFNBQVMsRUFBRTthQUMxQixJQUFJLENBQ0gsVUFBQyxLQUFjO1lBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxLQUFPLENBQUMsQ0FBQztRQUNyQyxDQUFDLENBQ0YsQ0FBQztRQUNGLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztZQUNoQyxLQUFLLEVBQUUseUJBQXlCO1lBQ2hDLE9BQU8sRUFBRSx5QkFBeUI7U0FDbkMsQ0FBQyxDQUFDLElBQUksQ0FDSDtZQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNFLENBQUMsRUFDRDtZQUNFLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQ0osQ0FBQTtJQUNILENBQUM7SUFDRCx5Q0FBYyxHQUFkO1FBQ0UsSUFBSSxjQUFjLEdBQUcsSUFBSSw0Q0FBYyxFQUFFLENBQUM7UUFDMUMsY0FBYyxDQUFDLElBQUksQ0FBQztZQUNsQixPQUFPLEVBQUUsaUJBQWlCO1lBQzFCLG9CQUFvQixFQUFFLElBQUk7WUFDMUIsVUFBVSxFQUFFLElBQUk7WUFDaEIsYUFBYSxFQUFFLGNBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBLENBQUEsQ0FBQztZQUNyRCxxQkFBcUIsRUFBRSxHQUFHO1lBQzFCLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLDJDQUEyQyxFQUFFLElBQUk7U0FDbEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLE1BQU07WUFDYiwrRkFBK0Y7WUFDL0YsS0FBSyxDQUFDO2dCQUNKLEtBQUssRUFBRSxhQUFhO2dCQUNwQixPQUFPLEVBQUUsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJO2dCQUNoRSxZQUFZLEVBQUUsSUFBSTthQUNuQixDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsVUFBQyxZQUFZO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUNGLENBQUM7SUFDRixDQUFDO0lBQ0gsdUJBQUM7QUFBRCxDQUFDLEFBNUhELElBNEhDO0FBakd5QjtJQUF2QixnQkFBUyxDQUFDLFdBQVcsQ0FBQzs4QkFBWSxpQkFBVTttREFBQztBQTNCbkMsZ0JBQWdCO0lBTjVCLGdCQUFTLENBQUM7UUFDVCxRQUFRLEVBQUUsUUFBUTtRQUNsQixTQUFTLEVBQUUsQ0FBQywwQkFBVyxDQUFDO1FBQ3hCLFdBQVcsRUFBRSw4QkFBOEI7UUFDM0MsU0FBUyxFQUFFLENBQUMsb0NBQW9DLEVBQUUsNkJBQTZCLENBQUM7S0FDakYsQ0FBQztxQ0E4QjJCLHVCQUFjLEVBQWtCLGVBQU0sRUFBdUIsMEJBQVcsRUFBZ0IsV0FBSTtHQTdCNUcsZ0JBQWdCLENBNEg1QjtBQTVIWSw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIE9uSW5pdCwgVmlld0NoaWxkIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuXHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3VzZXIvdXNlclwiO1xyXG5pbXBvcnQgeyBVc2VyU2VydmljZSB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdXNlci91c2VyLnNlcnZpY2VcIjtcclxuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XHJcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcImNvbG9yXCI7XHJcbmltcG9ydCB7IFZpZXcgfSBmcm9tIFwidWkvY29yZS92aWV3XCI7XHJcbmltcG9ydCAqIGFzIGNhbWVyYSBmcm9tIFwibmF0aXZlc2NyaXB0LWNhbWVyYVwiO1xyXG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJ1aS9pbWFnZVwiO1xyXG5pbXBvcnQgeyBCYXJjb2RlU2Nhbm5lciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYmFyY29kZXNjYW5uZXJcIjtcclxuaW1wb3J0IHsgRmluZ2VycHJpbnRBdXRoIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1maW5nZXJwcmludC1hdXRoXCI7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6IFwibXktYXBwXCIsXHJcbiAgcHJvdmlkZXJzOiBbVXNlclNlcnZpY2VdLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vcGFnZXMvY29uZmlybS9jb25maXJtLmh0bWxcIixcclxuICBzdHlsZVVybHM6IFtcIi4vcGFnZXMvY29uZmlybS9jb25maXJtLWNvbW1vbi5jc3NcIiwgXCIuL3BhZ2VzL2NvbmZpcm0vY29uZmlybS5jc3NcIl1cclxufSlcclxuZXhwb3J0IGNsYXNzIENvbmZpcm1Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIGZ1bGxuYW1lOiBzdHJpbmc7XHJcbiAgYW1vdW50OiBzdHJpbmc7XHJcbiAgYWFkaGFhcjogc3RyaW5nO1xyXG4gIHR5cGU6IHN0cmluZztcclxuICBwcml2YXRlIHN1YjogYW55O1xyXG4gIHB1YmxpYyBkaXNwbGF5cXIgPSBmYWxzZTtcclxuXHJcbiAgdG9nZ2xlUVIoKXtcclxuICAgIHRoaXMuZGlzcGxheXFyID0gIXRoaXMuZGlzcGxheXFyO1xyXG4gIH1cclxuXHJcbiAgb25UYXAoKSB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkZpcnN0Q29tcG9uZW50LlRhcHBlZCFcIik7XHJcbn1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgXHJcbiAgICAgIHRoaXMucm91dGUucGFyYW1zLmZvckVhY2goKHVybFBhcmFtcykgPT4ge1xyXG4gICAgICAgIHRoaXMuYW1vdW50PSB1cmxQYXJhbXNbJ2Ftb3VudCddO1xyXG4gICAgICAgIHRoaXMudHlwZT11cmxQYXJhbXNbJ3R5cGUnXTtcclxuXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICB1c2VyOiBVc2VyO1xyXG4gIGlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuICBAVmlld0NoaWxkKFwiY29udGFpbmVyXCIpIGNvbnRhaW5lcjogRWxlbWVudFJlZjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUsIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsIHByaXZhdGUgdXNlclNlcnZpY2U6IFVzZXJTZXJ2aWNlLCBwcml2YXRlIHBhZ2U6IFBhZ2UpIHtcclxuICAgIHRoaXMudXNlciA9IG5ldyBVc2VyKCk7XHJcbiAgICB0aGlzLnVzZXIuZW1haWwgPSBcInRlc3RjdXN0b21lckBtYXN0ZXJjYXJkLmNvbVwiO1xyXG4gICAgdGhpcy51c2VyLnBhc3N3b3JkID0gXCJwYXNzd29yZFwiO1xyXG4gICAgdGhpcy51c2VyLmNpdHkgPSBcIlB1bmVcIjtcclxuICAgIHRoaXMudXNlci5sb2NhbGl0eSA9IFwiWWVyd2FkYVwiO1xyXG4gICAgdGhpcy51c2VyLmZpcnN0bmFtZSA9IFwiU2FjaGluXCI7XHJcbiAgICB0aGlzLnVzZXIubGFzdG5hbWUgPSBcIkFncmF3YWxsYVwiO1xyXG4gICAgdGhpcy51c2VyLmFkZHJlc3MgPSBcIk1hc3RlcmNhcmQgOHRoIGZsb29yLCBZZXJ3YWRhXCI7XHJcbiAgICB0aGlzLnVzZXIucG9zdGFsY29kZSA9IFwiNDExMDAxXCI7XHJcbiAgICB0aGlzLnVzZXIubW9iaWxlID0gXCI3NzExMjIzMzQ0XCI7XHJcbiAgICB0aGlzLnVzZXIuZmlybW5hbWUgPSBcIkdyb2NlcnkgU3RvcmVcIjtcclxuICAgIHRoaXMuYWFkaGFhcj0nMjM0Mic7XHJcbiAgICB0aGlzLmZ1bGxuYW1lID0gdGhpcy51c2VyLmZpcnN0bmFtZSArIFwiIFwiICsgdGhpcy51c2VyLmxhc3RuYW1lO1xyXG4gIH1cclxuICBzdWJtaXQoKSB7XHJcbiAgICBpZiAodGhpcy5pc0xvZ2dpbmdJbikge1xyXG4gICAgICB0aGlzLmxvZ2luKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnNpZ25VcCgpO1xyXG4gICAgfVxyXG4gIH1cclxuICBsb2dpbigpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UubG9naW4odGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHRoaXMucm91dGVyLm5hdmlnYXRlKFtcIi9saXN0XCJdKSxcclxuICAgICAgICAoZXJyb3IpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSBjb3VsZCBub3QgZmluZCB5b3VyIGFjY291bnQuXCIpXHJcbiAgICAgICk7XHJcbiAgfVxyXG4gIHNpZ25VcCgpIHtcclxuICAgIHRoaXMudXNlclNlcnZpY2UucmVnaXN0ZXIodGhpcy51c2VyKVxyXG4gICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICgpID0+IHtcclxuICAgICAgICAgIGFsZXJ0KFwiWW91ciBhY2NvdW50IHdhcyBzdWNjZXNzZnVsbHkgY3JlYXRlZC5cIik7XHJcbiAgICAgICAgICB0aGlzLnRvZ2dsZURpc3BsYXkoKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgICgpID0+IGFsZXJ0KFwiVW5mb3J0dW5hdGVseSB3ZSB3ZXJlIHVuYWJsZSB0byBjcmVhdGUgeW91ciBhY2NvdW50LlwiKVxyXG4gICAgICApO1xyXG4gIH1cclxuICB0b2dnbGVEaXNwbGF5KCkge1xyXG4gICAgY2FtZXJhLnJlcXVlc3RQZXJtaXNzaW9ucygpO1xyXG4gICAgY2FtZXJhLnRha2VQaWN0dXJlKCkuXHJcbiAgICAgIHRoZW4oKGltYWdlQXNzZXQpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiUmVzdWx0IGlzIGFuIGltYWdlIGFzc2V0IGluc3RhbmNlXCIpO1xyXG4gICAgICAgICAgdmFyIGltYWdlID0gbmV3IEltYWdlKCk7XHJcbiAgICAgICAgICBpbWFnZS5zcmMgPSBpbWFnZUFzc2V0O1xyXG4gICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIC0+IFwiICsgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICB9KTtcclxuICB9XHJcbiAgc2NhbnBheSgpe1xyXG4gICAgbGV0IGZpbmdlcnByaW50QXV0aCA9IG5ldyBGaW5nZXJwcmludEF1dGgoKTtcclxuICAgIC8vdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL1wiXSk7XHJcbiAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICBmaW5nZXJwcmludEF1dGguYXZhaWxhYmxlKClcclxuICAgIC50aGVuKFxyXG4gICAgICAoYXZhaWw6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhgQXZhaWxhYmxlPyAke2F2YWlsfWApO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gICAgZmluZ2VycHJpbnRBdXRoLnZlcmlmeUZpbmdlcnByaW50KHtcclxuICAgICAgdGl0bGU6ICdTY2FuIGZpbmdlciB0byBjb250aW51ZScsIC8vIG9wdGlvbmFsIHRpdGxlICh1c2VkIG9ubHkgb24gQW5kcm9pZClcclxuICAgICAgbWVzc2FnZTogJ1NjYW4geW91ciBmaW5nZXIgdG8gcGF5J1xyXG4gICAgfSkudGhlbihcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgd2FzIE9LXCIpO1xyXG4gICAgICAgICAgc2VsZi5yb3V0ZXIubmF2aWdhdGUoW1wiL3N1Y2Nlc3NcIiwge2Ftb3VudDpzZWxmLmFtb3VudCwgdHlwZTpzZWxmLnR5cGV9XSk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZ2VycHJpbnQgTk9UIE9LXCIpO1xyXG4gICAgICAgIH1cclxuICAgIClcclxuICB9XHJcbiAgdG9nZ2xlRGlzcGxheTEoKSB7XHJcbiAgICBsZXQgYmFyY29kZXNjYW5uZXIgPSBuZXcgQmFyY29kZVNjYW5uZXIoKTtcclxuICAgIGJhcmNvZGVzY2FubmVyLnNjYW4oe1xyXG4gICAgICBmb3JtYXRzOiBcIlFSX0NPREUsIEVBTl8xM1wiLFxyXG4gICAgICBzaG93RmxpcENhbWVyYUJ1dHRvbjogdHJ1ZSxcclxuICAgICAgYmVlcE9uU2NhbjogdHJ1ZSwgXHJcbiAgICAgIGNsb3NlQ2FsbGJhY2s6ICgpID0+IHsgY29uc29sZS5sb2coXCJTY2FubmVyIGNsb3NlZFwiKX0sIFxyXG4gICAgICByZXN1bHREaXNwbGF5RHVyYXRpb246IDUwMCxcclxuICAgICAgb3JpZW50YXRpb246IFwicG9ydHJhaXRcIixcclxuICAgICAgb3BlblNldHRpbmdzSWZQZXJtaXNzaW9uV2FzUHJldmlvdXNseURlbmllZDogdHJ1ZVxyXG4gICAgfSkudGhlbigocmVzdWx0KSA9PiB7ICAgICAgXHJcbiAgICAgIC8vIE5vdGUgdGhhdCB0aGlzIFByb21pc2UgaXMgbmV2ZXIgaW52b2tlZCB3aGVuIGEgJ2NvbnRpbnVvdXNTY2FuQ2FsbGJhY2snIGZ1bmN0aW9uIGlzIHByb3ZpZGVkXHJcbiAgICAgIGFsZXJ0KHtcclxuICAgICAgICB0aXRsZTogXCJTY2FuIHJlc3VsdFwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRm9ybWF0OiBcIiArIHJlc3VsdC5mb3JtYXQgKyBcIixcXG5WYWx1ZTogXCIgKyByZXN1bHQudGV4dCxcclxuICAgICAgICBva0J1dHRvblRleHQ6IFwiT0tcIlxyXG4gICAgICB9KTtcclxuICAgIH0sIChlcnJvck1lc3NhZ2UpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJObyBzY2FuLiBcIiArIGVycm9yTWVzc2FnZSk7XHJcbiAgICB9XHJcbiAgKTtcclxuICB9XHJcbn0iXX0=