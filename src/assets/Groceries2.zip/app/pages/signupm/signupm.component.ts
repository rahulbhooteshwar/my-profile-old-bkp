import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";

import { User } from "../../shared/user/user";
import { UserService } from "../../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "ui/page";
import { Color } from "color";
import { View } from "ui/core/view";



@Component({
  selector: "my-app",
  providers: [UserService],
  templateUrl: "./pages/signupm/signupm.html",
  styleUrls: ["./pages/signupm/signupm-common.css", "./pages/signupm/signupm.css"]
})
export class SignupmComponent implements OnInit {
  isLoading = true;
  onTap() {
    console.log("FirstComponent.Tapped!");
}

    ngOnInit() {
      setTimeout(()=>{
        this.isLoading = false
      }, 4000);
        //this.page.actionBarHidden = true;
        //this.page.backgroundImage = "res://bg";
      }

  user: User;
  isLoggingIn = true;
  @ViewChild("container") container: ElementRef;

  constructor(private router: Router, private userService: UserService, private page: Page) {
    this.user = new User();
    this.user.email = "testmerchant@mastercard.com";
    this.user.password = "password";
    this.user.city = "Pune";
    this.user.locality = "Yerwada";
    this.user.firstname = "Shweta";
    this.user.lastname = "Gupta";
    this.user.address = "Mastercard 8th floor, Yerwada";
    this.user.postalcode = "411001";
    this.user.mobile = "7711223344";
  }
  submit() {
    this.router.navigate(["/mer1", this.user.firmname]);
  }
  login() {
    this.userService.login(this.user)
      .subscribe(
        () => this.router.navigate(["/list"]),
        (error) => alert("Unfortunately we could not find your account.")
      );
  }
  signUp() {
    this.userService.register(this.user)
      .subscribe(
        () => {
          alert("Your account was successfully created.");
          this.toggleDisplay();
        },
        () => alert("Unfortunately we were unable to create your account.")
      );
  }
  toggleDisplay() {
    this.router.navigate(["/"]);
  }
}