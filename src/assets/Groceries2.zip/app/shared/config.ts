export class Config {
  static apiUrl = "http://api.everlive.com/v1/GWfRtXi1Lwt4jcqK/";
  static token = "";
}