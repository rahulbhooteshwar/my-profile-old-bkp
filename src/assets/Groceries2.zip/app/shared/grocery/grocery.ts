export class Grocery {
    constructor(public id: string, public name: string) {}
  }