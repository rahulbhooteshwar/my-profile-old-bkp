"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = (function () {
    function Config() {
    }
    return Config;
}());
Config.apiUrl = "http://api.everlive.com/v1/GWfRtXi1Lwt4jcqK/";
Config.token = "";
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFBQTtJQUdBLENBQUM7SUFBRCxhQUFDO0FBQUQsQ0FBQyxBQUhEO0FBQ1MsYUFBTSxHQUFHLDhDQUE4QyxDQUFDO0FBQ3hELFlBQUssR0FBRyxFQUFFLENBQUM7QUFGUCx3QkFBTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb25maWcge1xuICBzdGF0aWMgYXBpVXJsID0gXCJodHRwOi8vYXBpLmV2ZXJsaXZlLmNvbS92MS9HV2ZSdFhpMUx3dDRqY3FLL1wiO1xuICBzdGF0aWMgdG9rZW4gPSBcIlwiO1xufSJdfQ==