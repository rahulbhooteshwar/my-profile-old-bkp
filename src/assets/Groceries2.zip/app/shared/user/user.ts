export class User {
    email: string;
    password: string;
    firstname: string;
    lastname: string;
    address: string;
    locality: string;
    city: string;
    postalcode: string;
    mobile: string;
    firmname: string;
    amount: string;
    consumerid: string;
    pin: string;
    customerid: string;
  }