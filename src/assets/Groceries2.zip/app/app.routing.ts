import { LoginComponent } from "./pages/login/login.component";
import { SignupComponent } from "./pages/signup/signup.component";
import { CustomerComponent } from "./pages/customer/customer.component";
import { MerchantComponent } from "./pages/merchant/merchant.component";
import { Signup1Component } from "./pages/signup1/signup1.component";
import { SignupmComponent } from "./pages/signupm/signupm.component";
import { ConfirmComponent } from "./pages/confirm/confirm.component";
import { SuccessComponent } from "./pages/success/success.component";
import { ListComponent } from "./pages/list/list.component";

export const routes = [
  { path: "", component: LoginComponent },
  { path: "signup", component: Signup1Component },
  { path: "cus1", component: CustomerComponent },
  { path: "signupc", component: SignupComponent },
  { path: "signupm", component: SignupmComponent },
  { path: "mer1/:id", component: MerchantComponent },
  { path: "list", component: ListComponent },
  { path: "confirm", component: ConfirmComponent },
  { path: "success", component: SuccessComponent }
];

export const navigatableComponents = [
  LoginComponent,
  SignupComponent,
  CustomerComponent,
  MerchantComponent,
  Signup1Component,
  SignupmComponent,
  ConfirmComponent,
  SuccessComponent,
  ListComponent
];